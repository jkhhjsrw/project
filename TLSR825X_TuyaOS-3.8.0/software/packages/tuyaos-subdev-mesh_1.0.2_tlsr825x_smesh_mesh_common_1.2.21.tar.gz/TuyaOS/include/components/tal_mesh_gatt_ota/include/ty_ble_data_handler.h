/*
 * tuya_data_handler.h
 *
 *  Created on: 2017-9-6
 *      Author: echo
 */

#ifndef TUYA_BLE_DATA_HANDLER_H_
#define TUYA_BLE_DATA_HANDLER_H_

#include "ty_ble_ota_adapt.h"

//BLE 通讯协议版本 v2.0 
#define protocol_ver_high       0x02
#define protocol_ver_low        0x00
#define PROTOCOL_VERSION_HIGN   0x02
#define PROTOCOL_VERSION_LOW    0x00
#define TY_APP_VER_NUM 0x0104
#define TY_HARD_VER_NUM 0x0100

#define ADVANCED_ENCRYPTION_DEVICE 0


//操作命令码
#define FRM_QRY_DEV_INFO_REQ  0x0000  //APP->BLE
#define FRM_QRY_DEV_INFO_RESP 0x0000  //BLE->APP
#define PAIR_REQ              0x0001  //APP->BLE
#define PAIR_RESP             0x0001  //BLE->APP
#define FRM_CMD_SEND          0x0002  //APP->BLE
#define FRM_CMD_RESP          0x0002  //BLE->APP
#define FRM_STATE_QUERY       0x0003  //APP->BLE
#define FRM_STATE_QUERY_RESP  0x0003  //BLE->APP
#define FRM_LOGIN_KEY_REQ     0x0004  //APP->BLE
#define FRM_LOGIN_KEY_RESP    0x0004  //BLE->APP
#define FRM_UNBONDING_REQ     0x0005  //APP->BLE
#define FRM_UNBONDING_RESP    0x0005  //BLE->APP
#define FRM_DEVICE_RESET      0x0006  //APP->BLE
#define FRM_DEVICE_RESET_RESP 0x0006  //BLE->APP

#define FRM_BULKDATA_START_REQ              0x0007  //APP->BLE
#define FRM_BULKDATA_START_CONFIRM          0x0008  //APP->BLE
#define FRM_BULKDATA_DATA_SEND_RESP         0x0009  //APP->BLE
#define FRM_BULKDATA_DATA_SEND_END_RESP     0x000A  //APP->BLE
#define FRM_BULKDATA_DATA_SEND_FORCED_END   0x000B  //APP->BLE


#define FRM_OTA_START_REQ         0x000C //APP->BLE
#define FRM_OTA_START_RESP        0x000C //BLE->APP
#define FRM_OTA_FILE_INFOR_REQ    0x000D //APP->BLE
#define FRM_OTA_FILE_INFOR_RESP   0x000D //BLE->APP
#define FRM_OTA_FILE_OFFSET_REQ   0x000E //APP->BLE
#define FRM_OTA_FILE_OFFSET_RESP  0x000E //BLE->APP
#define FRM_OTA_DATA_REQ          0x000F //APP->BLE
#define FRM_OTA_DATA_RESP         0x000F //BLE->APP
#define FRM_OTA_END_REQ           0x0010 //APP->BLE
#define FRM_OTA_END_RESP          0x0010 //BLE->APP

#define AIR_FRAME_MAX 600

#define TUYA_BLE_AIR_FRAME_MAX  (1024 + 512)

#define TUYA_BLE_DATA_MTU_MAX  247

#define TUYA_BLE_SEND_MAX_DATA_LEN                 (((TUYA_BLE_AIR_FRAME_MAX-17)/16)*16-14)

#define TUYA_BLE_RECEIVE_MAX_DATA_LEN              TUYA_BLE_SEND_MAX_DATA_LEN


extern UINT8_T pair_rand[6];
#define PAIR_RANDOM_LEN     6

typedef struct{
    UINT32_T send_len;
    UINT8_T*  send_data;
    UINT32_T encrypt_data_buf_len;
    UINT8_T*  encrypt_data_buf;
}r_air_send_packet;


typedef struct{
    UINT32_T recv_len;
    UINT32_T recv_len_max;
    UINT8_T* recv_data;
    UINT32_T decrypt_buf_len;
    UINT8_T* de_encrypt_buf;
}r_air_recv_packet;


VOID tuya_ble_commonData_rx_proc(UINT8_T *buf,UINT16_T len);

UINT8_T tuya_ble_commData_send(UINT16_T cmd,UINT32_T ack_sn,UINT8_T *data,UINT16_T len,UINT8_T encryption_mode);

#endif /* TUYA_DATA_HANDLER_H_ */


