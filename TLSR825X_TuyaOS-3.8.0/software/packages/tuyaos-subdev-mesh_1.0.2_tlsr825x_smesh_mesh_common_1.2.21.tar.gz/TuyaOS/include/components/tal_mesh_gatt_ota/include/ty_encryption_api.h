/*
 *  ty_encryption_api.h
 *
 *  Created on: 2019-4-12
 *  Author: gyh
 */

#ifndef TUYA_ENCRYPTION_API_H_
#define TUYA_ENCRYPTION_API_H_

#include "ty_ble_ota_adapt.h"

#ifdef __cplusplus
extern "C" {
#endif


extern UINT8_T tuya_aes_encryption(UINT8_T encryption_mode,UINT8_T *iv,UINT8_T *in_buf,UINT32_T in_len,UINT32_T *out_len,UINT8_T *out_buf);
extern UINT8_T tuya_aes_decryption(UINT8_T const *in_buf,UINT32_T in_len,UINT32_T *out_len,UINT8_T *out_buf);

#ifdef __cplusplus
}
#endif

#endif // TUYA_ENCRYPTION_API_H_
