/*************************************************************************
	> File Name: alg_ota.h
	> Author: 
	> Mail: 
	> Created Time: Tue 21 May 2019 10:41:15 CST
 ************************************************************************/

#ifndef _ALG_OTA_H
#define _ALG_OTA_H

#include "ty_ble_ota_adapt.h"

#define OTA_DATA_PACKET_SIZE  1024

//#define TUYA_OTA_NOTIFY_HANDLE 0x2E
extern const UINT8_T TUYA_OTA_NOTIFY_HANDLE;

typedef enum{
    WAIT_FOR_START=1,
    WAIT_FOR_COPY,
    APP_DOWNLOADING,
    BOOT_DOWNLOADING,
    ENTER_BOOTLOADER=0xF0,
}e_ota_status_t;

typedef struct{
//    UINT8_T   image_md5[16];
    UINT32_T  image_addr;
    UINT32_T  image_length;
    UINT32_T  image_crc32;
//    UINT32_T  res[5];
}new_image_t;

typedef struct{
    UINT8_T   ota_mac[8];
    UINT8_T   ota_adv_name[20];
    UINT8_T   ota_pid[8];
    UINT8_T   ota_did[16];
    UINT8_T   ota_autrkey[32];
}product_infor_t;

typedef struct{
    UINT32_T  image_length;
    UINT32_T  image_crc32;
    UINT32_T  image_addr;
}ota_settings_t;

typedef struct{
    UINT32_T  sn;
    UINT32_T  sn_ack;
    UINT16_T  cmd;
    UINT16_T  lenth;
    UINT16_T  crc;
}tuya_ota_packet_handle;

UINT32_T crc32_compute(UINT8_T const * p_data, UINT32_T size, UINT32_T const * p_crc);
unsigned short crc16_compute(unsigned char *pD, int len);

VOID tuya_ota_proc(UINT16_T cmd,UINT8_T*recv_data,UINT32_T recv_len);
UINT32_T tuya_ota_init(VOID);
#endif
