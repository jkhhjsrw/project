/*
 * tuya_ble_commdata_handler.h
 *
 *  Created on: 2019-4-17
 *      Author: gyh
 */

#ifndef TUYA_BLE_COMMDATA_HANDLER_H_
#define TUYA_BLE_COMMDATA_HANDLER_H_

#include "ty_ble_ota_adapt.h"

#ifdef __cplusplus
extern "C" {
#endif

enum
{
	FACTORY_CMD_LED=0x0001,
	FACTORY_CMD_WIFIRSSI=0x0100,
	FACTORY_CMD_KEY=0x0003,
	FACTORY_SWITCH_SENSOR = 0x0004,	
	FACTORY_ANALOG_SENSOR=0x0006,	
	FACTORY_CMD_MAC=0x0014,
	FACTORY_CMD_PID=0X0015,
	FACTORY_CMD_FINGER=0X0016,
	FACTORY_CMD_MAX,
};

VOID ty_ble_evt_process(UINT16_T cmd, UINT8_T*recv_data, UINT32_T recv_len);


#ifdef __cplusplus
}
#endif

#endif // TUYA_BLE_COMMDATA_HANDLER_H_




