/**
* @file ty_ble_ota_adapt.h
* @brief Common process - adapter the spi api
* @version 0.1
* @date 2021-08-06
*
* @copyright Copyright 2020-2021 Tuya Inc. All Rights Reserved.
*
*/
#ifndef __TY_BLE_OTA_ADAPT_H__
#define __TY_BLE_OTA_ADAPT_H__

#include <stddef.h>
#include <stdint.h>
//#include <stdlib.h>
#include <string.h>

#include "tuya_cloud_types.h"
#include "tal_log.h"

#define TY_MALLOC_ENABLE  1

//#define APP_LOG(...)                        TAL_PR_DEBUG(__VA_ARGS__)
//#define APP_LOG_DUMP(title, buffer, len)    TAL_PR_HEXDUMP_DEBUG(title, buffer, len)
#define APP_LOG(...)
#define APP_LOG_DUMP(title, buffer, len)

typedef enum
{
    ENCRYPTION_MODE_NONE,
    ENCRYPTION_MODE_KEY_1,//MD5（auth_key）的结果16字节转32个字符，取第8-24个字符
    ENCRYPTION_MODE_KEY_2,//MD5（secret_key_1,srand）的结果16字节转32个字符，取第8-24个字符，只用于配对请求指令。
    ENCRYPTION_MODE_KEY_3,//MD5(secret_key_1,srand,user_rand) 的结果16字节转32个字符，取第8-24个字符,适用于高级加密设备
    ENCRYPTION_MODE_KEY_4,//MD5（login_key）的结果16字节转32个字符，取第8-24个字符
    ENCRYPTION_MODE_SESSION_KEY,//MD5（login_key,srand）的结果16字节转32个字符，取第8-24个字符
    ENCRYPTION_MODE_MAX,
} ENCRYPTION_MODE_T;

typedef struct
{
    UINT32_T file_lenth;
    UINT32_T file_crc32;
} ota_file_info_t;

typedef VOID (*tal_ble_data_recv_cb)(UINT16_T cmd, UINT8_T*recv_data, UINT16_T recv_len);

VOID tal_ble_data_callback_init(tal_ble_data_recv_cb data_cb);

OPERATE_RET tal_ble_data_send(UINT16_T cmd, UINT32_T ack_sn, UINT8_T *data, UINT16_T len, ENCRYPTION_MODE_T mode);

VOID tuya_hal_wactchdog_clear(VOID);

VOID tal_mesh_gatt_ota_version_set(UINT16_T version);

VOID tal_ota_mesh_devkey_get(UINT8_T *key);

UINT16_T tal_ota_get_mesh_firm_version_hex(VOID);

int tal_ota_data_notify(UINT8_T* data, int data_len);

VOID tal_ota_connect_param_update(UINT16_T intervalMin, UINT16_T intervalMax, UINT16_T slaveLatency, UINT16_T timeoutMultiplier);

VOID tal_ble_ota_data_recv(UINT8_T *buf, UINT16_T len);

VOID tal_ble_ota_init(VOID);

VOID tal_ota_disconnect_proc(VOID);

UINT32_T tuya_OTASaveData(UINT32_T adr, UINT8_T *data,UINT16_T len);

#endif


