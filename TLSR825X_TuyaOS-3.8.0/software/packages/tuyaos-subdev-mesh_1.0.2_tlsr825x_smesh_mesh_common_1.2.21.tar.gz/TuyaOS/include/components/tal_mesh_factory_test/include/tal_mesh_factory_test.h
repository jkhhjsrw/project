/**
 * @file tal_mesh_factory_test.h
 * @brief This is tuya tal_mesh_factory_test file
 * @version 1.0
 * @date 2021-12-23
 *
 * @copyright Copyright 2021-2031 Tuya Inc. All Rights Reserved.
 *
 */

#ifndef _TAL_MESH_PRODUCT_TEST_H_
#define _TAL_MESH_PRODUCT_TEST_H_

#define  F_HEAD1                     0x00
#define  F_HEAD2                     0x01
#define  F_HEAD3                     0x02
#define  F_CMD                       0x03
#define  F_LEN1                      0x04
#define  F_LEN2                      0x05
#define  F_DATA                      0x06
#define  F_MIN_LEN                   0x07

typedef UINT8_T country_code_t;
#define COUNTRY_CODE_CN     0
#define COUNTRY_CODE_US     1
#define COUNTRY_CODE_JP     2
#define COUNTRY_CODE_EU     3
#define COUNTRY_CODE_JP1    4

#define H_ID_LEN                    20
#define P_ID_LEN                    8
#define AUTH_KEY_LEN                32
#define UUID_LEN                    16
#define MAC_LEN                     12
#define FIRMNAME_MAX_LEN            32
#define FIRMVERSION_MAX_LEN         10


typedef enum {
    NV_USER_ITEM_H_ID,
    NV_USER_ITEM_AUZ_KEY,
    NV_USER_ITEM_UUID,
    NV_USER_ITEM_MAC,
    NV_USER_ITEM_PID,
    NV_USER_ITEM_CONFIG,
    NV_USER_ITEM_IF_AUTH,
    NV_USER_ITEM_COUNTRY_CODE,
    NV_USER_ITEM_COUNTRY_TX_dBm,
} nv_userItemId_t;//only read


#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_ENTER                 0x00
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_QUERY_HID             0x01
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_GPIO_TEST             0x02
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_WRITE_AUTH_INFO       0x03
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_QUERY_INFO            0x04
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_RESET                 0x05
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_QUERY_FINGERPRINT     0x06
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_WRITE_HID             0x07
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_RSSI_TEST             0x08
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_WRITE_OEM_INFO        0x09

#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_START_SUBC            0x0C
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_STOP_SUBC             0x0D
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_WRITE_COUNTRY_CODE    0x0E
#define      CMD_UART_CMD_SERVER_FOR_FACTORY_TEST_READ_COUNTRY_CODE     0x0F

#define      CMD_UART_CMD_SERVER_FOR_BLE_SDK_TEST_EXTEND                0xF2


/**
  * @brief      Get the configuration information of the No-Code Development device.
  * @param[in]  para: config data
  * @param[in]  len: config data lenth
  *
  * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
  */
OPERATE_RET tal_oem_cfg_info_load(UINT8_T *para, UINT16_T* len);

/**
 * @brief      Use for app th set the firmware information.
 *
 * @param[in]  *firmname: firmname string, such as "tuya_mesh_base_demo".
 * @param[in]  *version: version string, such as "1.0".
 *
 * @return None
 */
VOID tal_mesh_factory_firmware_info_set(UINT8_T *firmname, UINT8_T *version);

/**
 * @brief      Factory test cmd data callback.
 *
 * @param[in]  cmd: command
 * @param[in]  *para: data
 * @param[in]  len: data lenth
 *
 * @return None
 */
VOID tal_mesh_factory_test_receive_cmd(UINT8_T cmd, UINT8_T *para, UINT16_T len);

/**
 * @brief      Factory test data send.
 *
 * @param[in]  cmd: command
 * @param[in]  *para: data
 * @param[in]  len: data lenth
 *
 * @return None
 */
VOID tal_mesh_factory_test_send_cmd(UINT8_T cmd, UINT8_T *para, UINT16_T len);


/**
  * @brief      Get whether the device is authorized by tuya.
  *
  * @return     1 is authorized, 0 is not
  */
UINT8_T tal_factory_test_auth_by_tuya(VOID);

/**
  * @brief      Set mesh device auth information.
  * @param[in]  uuid     - device uuid, 16 byte
  * @param[in]  auth_key - key,32 byte data
  * @param[in]  mac      - mac str, 12 byte
  *
  * @return     Status
  */
OPERATE_RET tal_device_auth_infor_set(UINT8_T *uuid, UINT8_T *auth_key, UINT8_T *mac);

/**
  * @brief      Get mesh device auth information.
  * @param[in]  uuid     - device uuid, 16 byte
  * @param[in]  auth_key - key,32 byte data
  * @param[in]  mac      - mac str, 12 byte
  *
  * @return     Status
  */
OPERATE_RET tal_device_auth_infor_get(UINT8_T *uuid, UINT8_T *auth_key, UINT8_T *mac);

/**
  * @brief      Factory uart init.
  * @return
  */
VOID_T tal_factory_test_uart_init(VOID_T);


#endif

