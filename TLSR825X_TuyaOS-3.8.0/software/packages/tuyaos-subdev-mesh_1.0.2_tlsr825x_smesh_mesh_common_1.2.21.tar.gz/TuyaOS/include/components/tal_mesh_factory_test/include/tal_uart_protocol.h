/**
 * @file tal_uart_protocol.h
 * @brief This is tuya tal_uart_protocol file
 * @version 1.0
 * @date 2021-12-23
 *
 * @copyright Copyright 2021-2031 Tuya Inc. All Rights Reserved.
 *
 */

#ifndef _TAL_UART_PROTOCOL_H_
#define _TAL_UART_PROTOCOL_H_

OPERATE_RET tal_uart_receive_common_data(UINT8_T *p_data, UINT16_T len);



#endif
