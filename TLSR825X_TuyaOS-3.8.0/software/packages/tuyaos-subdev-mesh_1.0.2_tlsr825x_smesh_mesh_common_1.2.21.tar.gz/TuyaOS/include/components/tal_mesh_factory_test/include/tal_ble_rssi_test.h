/**
 * @file tal_ble_rssi_test.h
 * @brief This is tuya tal_ble_rssi_test file
 * @version 1.0
 * @date 2021-12-23
 *
 * @copyright Copyright 2021-2031 Tuya Inc. All Rights Reserved.
 *
 */

#ifndef _TAL_BLE_RSSI_TEST_H_
#define _TAL_BLE_RSSI_TEST_H_

#include "tuya_cloud_types.h"
#include "tuya_error_code.h"


typedef enum{
    TY_PROD_RSSI = 0x00,
    TY_MDEV_RSSI,
}ty_tssi_type_t;


VOID tal_rssi_test_init(VOID);

VOID tal_rssi_test_ble_adv_recv(UINT8_T *adv, UINT8_T adv_len, UINT8_T *mac, int rssi);

VOID tal_rssi_prod_test_update_name(UINT8_T *para, UINT8_T len);

VOID tal_rssi_base_test_start(ty_tssi_type_t test_type);

VOID tal_rssi_base_test_stop(ty_tssi_type_t test_type);

OPERATE_RET tal_rssi_prod_test_rssi_get(INT8_T *rssi);

OPERATE_RET ty_rssi_base_test_get_rssi_avg(INT32_T *rssi, ty_tssi_type_t type);




#endif
