/**
 * @file tal_bluetooth_mesh_firmware_infor_inner.h
 * @brief This is tuya tal_adc file
 * @version 1.0
 * @date 2021-09-10
 *
 * @copyright Copyright 2021-2031 Tuya Inc. All Rights Reserved.
 *
 */

#ifndef __TAL_BLUETOOTH_MESH_FIRMWARE_INFOR_INNER_H__
#define __TAL_BLUETOOTH_MESH_FIRMWARE_INFOR_INNER_H__

typedef struct {
    UINT8_T     is_key;                             /**< Mesh Node Address */
    UINT8_T     pid_or_key[8];                             /**< Mesh Data, structure refer to @TAL_BLE_DATA_T */
    UINT16_T    version;
    UINT16_T    mesh_category;
    UINT16_T    mesh_category_ext;
    UINT8_T     need_publish_addr;
}TAL_MESH_FIRMWARE_INFOR_T;


/**
 * @brief   Get pid or firmware key of the device.
 * @param   [out] pid_or_key: point of firmware key or product id
 * @return  1 : param pid_or_key is firmware key
 *          0 : param pid_or_key is product id
 * */
UINT8_T tal_get_firmware_key_or_pid(UINT8_T *pid_or_key);

/**
 * @brief   Get firmware version(hex) of the device.
 * @return  Hex data(ASCII) of firmware version. 0x3135 = 5.1
 * */
UINT16_T tal_get_firmware_version(VOID);

/**
 * @brief   Get mesh category of the device.
 * @return  Mesh category
 * */
UINT16_T tal_get_firmware_mesh_category(VOID);

/**
 * @brief   Get extended mesh category of the device.
 * @return  Extended mesh category
 * */
UINT16_T tal_get_firmware_mesh_category_ext(VOID);

/**
 * @brief   Set pid or firmware key of the device.
 * @param   [in] is_key: if the param pid_or_key is firmware key
 * @param   [in] pid_or_key: point of firmware key or product id
 * @return  NULL
 * */
VOID_T tal_firmware_key_or_pid_set(UINT8_T is_key, UINT8_T *pid_or_key);

/**
 * @brief   Set firmware version of the device.
 * @param   [in] version: firmware version
 * @return  NULL
 * */
VOID_T tal_firmware_version_set(UINT16_T version);

/**
 * @brief   Set mesh category of the device.
 * @param   [in] mesh_category: mesh category
 * @return  NULL
 * */
VOID_T tal_firmware_mesh_category_set(UINT16_T mesh_category);

/**
 * @brief   Set the flag which indicate whether the device need publish addr.
 * @param   [in] need_publish_addr: flag
 * @return  NULL
 * */
VOID_T tal_firmware_if_need_publish_addr_set(UINT8_T need_publish_addr);

/**
 * @brief   Set the flag whether the device enable the advanced ability 1.
 *          if enable this ability,the device well support 3 ability:
 *          1. App and gateway will use vendor get cmd to get the device's data points.
  *         2. The device support WRITE_WITH_TID opcode.When the data point use seq access message,app and gateway will use WRITE_WITH_TID,
               and the device can only response the TID,not all the data point.
 * @param   [in] need_publish_addr: flag
 * @return  NULL
 * */
VOID_T tal_mesh_advanced_ability_1(UINT8_T enable);


#endif
