/**
* @file tal_asymmetrical.h
* @brief Common process - adapter the asymmetrical api  provide by OS
* @version 0.1
* @date 2022-04-22
*
* @copyright Copyright 2021-2025 Tuya Inc. All Rights Reserved.
*
*/

#ifndef __TAL_ASYMMETRICAL_H__
#define __TAL_ASYMMETRICAL_H__

#include "tuya_cloud_types.h"
#include "tkl_asymmetrical.h"

#ifdef __cplusplus
    extern "C" {
#endif

typedef enum{    
    TYPE_PRIVATE = 0,
    TYPE_PUBLIC = 1,
}TAL_ASYMMETRICAL_KEY_TYPE;

typedef enum{    
    FORMAT_PEM = 0,
    FORMAT_DER = 1,
}TAL_ASYMMETRICAL_KEY_FORMAT;

/**
* @brief This function Create&initializes a rsa context.
*
* @param[out] ctx: rsa handle
*
* @note This API is used to create and init rsa.
*
* @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
*/
OPERATE_RET  tal_rsa_create_init( TKL_ASYMMETRICAY_HANDLE *ctx );

/**
* @brief This function releases and clears the specified rsa context.
*
* @param[in] ctx: The rsa context to clear.
*
* @note This API is used to release rsa.
*
* @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
*/
OPERATE_RET  tal_rsa_free( TKL_ASYMMETRICAY_HANDLE ctx );

/**
 * @brief          This function generates an RSA keypair.
 *
 * @note           tal_rsa_create_init() must be called before this function,
 *                 to set up the RSA context.
 *
 * @param ctx      The initialized RSA context used to hold the key. 
 * @param nbits    The size of the public key in bits.
 * @param exponent The public exponent to use. For example, \c 65537.
 *                 This must be odd and greater than \c 1.
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h 
 */
OPERATE_RET  tal_rsa_gen_key(TKL_ASYMMETRICAY_HANDLE ctx,
                                UINT32_T nbits,
                                INT32_T exponent);
/**
 * @brief           Write a private key to a PKCS#1 or SEC1 DER structure
 *                  Note: data is written at the end of the buffer! Use the
 *                        return value to determine where you should start
 *                        using the buffer
 *
 * @param ctx       RSA context which must contain a valid private or public key.
 * @param output_mode       privat or public
 * @param output_format     DER or PEM
 * @param output_buf       buffer to write to
 * @param size      size of the buffer
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
OPERATE_RET tal_rsa_export_key( TKL_ASYMMETRICAY_HANDLE ctx,
                                    TAL_ASYMMETRICAL_KEY_TYPE output_mode,
                                    TAL_ASYMMETRICAL_KEY_FORMAT output_format,
                                    UINT8_T *output_buf, size_t size );

/**
 * @brief           Parse a public key in PEM or DER format
 *                  Note: data is written at the end of the buffer! Use the
 *                        return value to determine where you should start
 *                        using the buffer
 *
 * @param ctx       RSA context which must contain a valid private or public key.
 * @param output_mode       privat or public
 * @param output_format     DER or PEM
 * @param input_buf       buffer to write to
 * @param size      size of the buffer
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
OPERATE_RET tal_rsa_import_key( TKL_ASYMMETRICAY_HANDLE ctx,
                                    TAL_ASYMMETRICAL_KEY_TYPE input_mode,
                                    TAL_ASYMMETRICAL_KEY_FORMAT input_format,
                                    UINT8_T *input_buf, size_t size );   


/**
 * @brief          This function performs a PKCS#1 v1.5 signature
 *                 operation (RSASSA-PKCS1-v1_5-SIGN).
 *
 * @param ctx      The initialized RSA context to use. 
 * @param hashlen  The length of the message digest or raw data in Bytes.
 *                 If \p md_alg is not #MBEDTLS_MD_NONE, this must match the
 *                 output length of the corresponding hash algorithm.
 * @param hash     The buffer holding the message digest or raw data.
 *                 This must be a readable buffer of at least \p hashlen Bytes.
 * @param sig      The buffer to hold the signature. This must be a writable
 *                 buffer of length \c ctx->len Bytes. For example, \c 256 Bytes
 *                 for an 2048-bit RSA modulus. A buffer length of
 *                 #MBEDTLS_MPI_MAX_SIZE is always safe.
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
OPERATE_RET tal_rsa_sha256_pkcs1_v15_sign( TKL_ASYMMETRICAY_HANDLE ctx,                               
                               unsigned int hashlen,
                               const UINT8_T *hash,
                               UINT8_T *sig );   

/**
 * @brief          This function performs a PKCS#1 v1.5 verification
 *                 operation (RSASSA-PKCS1-v1_5-VERIFY).
 *
 * @param ctx      The initialized RSA public key context to use. 
 * @param hashlen  The length of the message digest or raw data in Bytes.
 *                 If \p md_alg is not #MBEDTLS_MD_NONE, this must match the
 *                 output length of the corresponding hash algorithm.
 * @param hash     The buffer holding the message digest or raw data.
 *                 This must be a readable buffer of at least \p hashlen Bytes.
 * @param sig      The buffer holding the signature. This must be a readable
 *                 buffer of length \c ctx->len Bytes. For example, \c 256 Bytes
 *                 for an 2048-bit RSA modulus.
 *
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
OPERATE_RET tal_rsa_sha256_pkcs1_v15_verify( TKL_ASYMMETRICAY_HANDLE ctx,                                 
                                 unsigned int hashlen,
                                 const UINT8_T *hash,
                                 const UINT8_T *sig );

#ifdef __cplusplus
}
#endif

#endif
