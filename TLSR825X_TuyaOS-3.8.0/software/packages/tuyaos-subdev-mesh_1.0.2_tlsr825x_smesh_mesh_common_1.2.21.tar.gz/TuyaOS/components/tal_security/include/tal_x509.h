/**
* @file tal_x509.h
* @brief Common process - adapter the tal_x509 api
* @version 0.1
* @date 2022-04-22
*
* @copyright Copyright 2021-2025 Tuya Inc. All Rights Reserved.
*
*/
#ifndef __TAL_X509_H__
#define __TAL_X509_H__

#include "tuya_cloud_types.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

