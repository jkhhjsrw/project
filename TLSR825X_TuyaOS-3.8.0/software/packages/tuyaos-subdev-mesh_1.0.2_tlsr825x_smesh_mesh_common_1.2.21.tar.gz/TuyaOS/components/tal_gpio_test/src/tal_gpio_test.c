/**
 * @file tal_gpio_test.c
 * @brief This is tuya tal_gpio_test file
 * @version 1.0
 * @date 2021-12-23
 *
 * @copyright Copyright 2021-2031 Tuya Inc. All Rights Reserved.
 *
 */

#include "tal_gpio_test.h"


extern TUYA_GPIO_NUM_E tkl_gpio_test_list[];

static inline UINT8_T check_num(UINT8_T *ret,UINT8_T num){
    UINT8_T i = 0;
    for(;i < ret[0];i++){
        if(ret[i+1] == num){
            return 1;
        }
    }
    return 0;
}


/*
 * 条件：按照map表中的设置将对应引脚互联
 * 算法：所有待测引脚默认拉高输入，对其中任意一个引脚设置为输出低电平，检测其他引脚逻辑是否正确（互联/没有互联）
 * 返回：ret[0]表示异常的引脚数量，ret[1..]表示异常的引脚编号（标号为acill表示）
 *
 * 特别的：对于总IO为1的测试案例，直接外部串联电阻挂在VCC上，这里将该引脚设置为下拉输入，然后读电平是否为高
 */
static inline void ty_gpio_base_test_start(ty_gpio_base_test_s *p_gpio_test){
    UINT8_T j = 0,i = 0,index = 1;
    TUYA_GPIO_LEVEL_E level;
    
    UINT8_T pin_cnt = p_gpio_test->pin_cnt;
    TUYA_GPIO_NUM_E *pin =  p_gpio_test->pin;
    UINT8_T *pin_num = p_gpio_test->pin_num;
    UINT8_T *map = p_gpio_test->map;
    UINT8_T *ret = p_gpio_test->ret;

    ret[0] = 0;
    if(pin_cnt == 1){//special gpio_num == 1

        TUYA_GPIO_BASE_CFG_T gpio_cfg = {
            .mode = TUYA_GPIO_PULLDOWN,
            .direct = TUYA_GPIO_INPUT,
        };
        tkl_gpio_init(pin[0], &gpio_cfg);
        tkl_gpio_read(pin[0], &level);
        if(TUYA_GPIO_LEVEL_LOW == level){
            ret[0]++;
            ret[index++] = 0 + 0x30;
        }
    }else{
        for(j=0;j<pin_cnt;j++){
            TUYA_GPIO_BASE_CFG_T gpio_cfg_input = {
                .mode = TUYA_GPIO_PUSH_PULL,
                .direct = TUYA_GPIO_INPUT,
            };
            for(i=0;i<pin_cnt;i++){
                tkl_gpio_init(pin[i], &gpio_cfg_input);
            }

            TUYA_GPIO_BASE_CFG_T gpio_cfg_output = {
                .mode = TUYA_GPIO_PULLDOWN,
                .direct = TUYA_GPIO_OUTPUT,
                .level = TUYA_GPIO_LEVEL_LOW,
            };
            tkl_gpio_init(pin[j], &gpio_cfg_output);

            for(i=0; i<pin_cnt; i++){
                if(j != i){
                    tkl_gpio_read(pin[i], &level);
                    if(map[i] == map[j]){
                        if((TUYA_GPIO_LEVEL_LOW != level) && (0 == check_num(ret, pin_num[j]))){
                            ret[0]++;
                            ret[index++] = pin_num[j];
                        }
                    }else{
                        if((TUYA_GPIO_LEVEL_LOW == level) && (0 == check_num(ret, pin_num[j]))){
                            ret[0]++;
                            ret[index++] = pin_num[j];
                        }
                    }
                }
            }
        }
    }

//    app_log_dump("gpio", p_gpio_test, sizeof(ty_gpio_base_test_s));
}

TUYA_GPIO_NUM_E get_pin_num_io(UINT8_T pin_num){
    return tkl_gpio_test_list[pin_num];
}

#define IS_NUM(c)  (c >= '0' && c <= '9')
#define C_TO_NUM(c)  (c - '0')

/*
 * 根据用户配置自动测试，测试成功返回1，失败返回0
 */
UINT8_T ty_gpio_base_test_auto(UINT8_T *para, UINT8_T len, UINT8_T *result){
    ty_gpio_base_test_s gpio_test_cases_cloud;
    UINT8_T pin_cnt = 0;
    UINT8_T group_id = 1;

    if(len == 0){
        return 1;
    }

//    app_printf("gpio:%s\r\n", para);
    for(int i = 0; i < len; i++){
        if(para[i] == '"' && IS_NUM(para[i+1])){
            if(IS_NUM(para[i+2])){
                UINT8_T num = C_TO_NUM(para[i+1]) * 10 + C_TO_NUM(para[i+2]);
                gpio_test_cases_cloud.pin_num[pin_cnt] = num;
                gpio_test_cases_cloud.pin[pin_cnt] = get_pin_num_io(num);
                gpio_test_cases_cloud.map[pin_cnt] = group_id;
            }
            else{
                gpio_test_cases_cloud.pin_num[pin_cnt] = C_TO_NUM(para[i+1]);
                gpio_test_cases_cloud.pin[pin_cnt] = get_pin_num_io(C_TO_NUM(para[i+1]));
                gpio_test_cases_cloud.map[pin_cnt] = group_id;
            }
            pin_cnt++;
        }
        if(para[i] == ',' && IS_NUM(para[i+1])){
            if(IS_NUM(para[i+2])){
                UINT8_T num = C_TO_NUM(para[i+1]) * 10 + C_TO_NUM(para[i+2]);
                gpio_test_cases_cloud.pin_num[pin_cnt] = num;
                gpio_test_cases_cloud.pin[pin_cnt] = get_pin_num_io(num);
                gpio_test_cases_cloud.map[pin_cnt] = group_id;
            }
            else{
                gpio_test_cases_cloud.pin_num[pin_cnt] = C_TO_NUM(para[i+1]);
                gpio_test_cases_cloud.pin[pin_cnt] = get_pin_num_io(C_TO_NUM(para[i+1]));
                gpio_test_cases_cloud.map[pin_cnt] = group_id;
            }
            pin_cnt++;
        }
        if(para[i] == '"' && (para[i+1] == ',' || para[i+1] == ']')){
            group_id++;
        }
    }
    gpio_test_cases_cloud.pin_cnt = pin_cnt;

    ty_gpio_base_test_start(&gpio_test_cases_cloud);
    if(gpio_test_cases_cloud.ret[0] == 0){
        return 1;
    }
    else{
        memcpy(result, gpio_test_cases_cloud.ret, MAX_GPIO_TEST_PIN_MORE);
        return 0;
    }
}









