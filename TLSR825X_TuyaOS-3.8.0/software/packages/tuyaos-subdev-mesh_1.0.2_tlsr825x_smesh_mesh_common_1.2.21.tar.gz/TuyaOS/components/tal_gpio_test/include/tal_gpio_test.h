/**
 * @file tal_gpio_test.h
 * @brief This is tuya tal_gpio_test file
 * @version 1.0
 * @date 2021-12-23
 *
 * @copyright Copyright 2021-2031 Tuya Inc. All Rights Reserved.
 *
 */

#ifndef _TAL_GPIO_TEST_H_
#define _TAL_GPIO_TEST_H_

#include "tkl_gpio.h"


#define MAX_GPIO_TEST_PIN       (18)
#define MAX_GPIO_TEST_PIN_MORE  (MAX_GPIO_TEST_PIN + 1)   //=8+1


typedef struct{
    UINT8_T         pin_cnt;
    TUYA_GPIO_NUM_E pin[MAX_GPIO_TEST_PIN];
    UINT8_T         pin_num[MAX_GPIO_TEST_PIN];
    UINT8_T         map[MAX_GPIO_TEST_PIN];
    UINT8_T         ret[MAX_GPIO_TEST_PIN_MORE];
}ty_gpio_base_test_s;

UINT8_T ty_gpio_base_test_auto(UINT8_T *para, UINT8_T len, UINT8_T *result);


#endif
