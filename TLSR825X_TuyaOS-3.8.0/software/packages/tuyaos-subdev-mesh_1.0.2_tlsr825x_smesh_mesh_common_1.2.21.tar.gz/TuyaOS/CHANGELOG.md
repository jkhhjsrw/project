# 版本更新日志

# V3.6.0 - 2022/12/13

## 摘要

3.6.0 相对前期版本优化较多，搭配 **4.8.0** 以上的 APP 以及新版本网关则有较好的性能与稳定性表现。

## 添加

1. 新增带 TID 命令下发，优化 mesh 长包数据控制体验；（参考 TuyaOS_BLE_Mesh_Application_Guide.md 文件中**带 TID 命令下发**介绍）
2. 优化心跳功能，使用 vendor 数据心跳；（参考 TuyaOS_BLE_Mesh_Application_Guide.md 文件中**Vendor 心跳**介绍）
3. 新增设备本地重置（APP 上数据不删除）后配网，设备群组信息恢复功能，无需为设备重新配置群组；
4. 新增设备状态回复通道，实现多 DP 数据打包回复；（参考 TuyaOS_BLE_Mesh_Application_Guide.md 文件中**新状态回复通道**介绍）

## 修改

1. 优化群组绑定逻辑，同一 element 下不同 model 间分享群组地址订阅，可提高 provisioner 给设备添加/解散群组速度；
2. 优化 mesh provision 流程，增加 APP key 自绑定功能，无需 provisioner 单独给 model 绑定 appkey；
3. 优化 mesh provision PB-GATT 路径流程，支持 mesh provision 与 proxy 服务共存，节省配网过程中的断连重连过程，提高成功率与速度；

## 性能

1. 优化中国区发射功率，提升设备拉距、抗遮挡等射频性能；
2. 提升 OTA 传输速率；
3. 优化设备发包 fifo 处理，降低设备快速发包时丢包的概率；

## 其它

其它部分，暂无。



# V3.8.0 - 2023/6/30

## 摘要

优化 kernal 接口，修复部分问题。

## 添加

1. 新增 OTA 开始/结束 状态推送；
2. 新增 Phy6222 bypass 模式支持；

## 修改

1. 优化 ADC 初始化参数，使用 ch_list。并优化内部测量模式，选择内部模式下无需额外 GPIO 初始化操作；
2. 整合 vendor dp 查询功能与 write with TID 功能，支持接口配置开启/关闭；
3. 修复授权产测组件 UART 数据解析问题；
4. 修复 Tlsr825x 3.6.0 版本未配网模式下关闭广播接口无效问题；

## 性能

无

## 其它

其它部分，暂无。