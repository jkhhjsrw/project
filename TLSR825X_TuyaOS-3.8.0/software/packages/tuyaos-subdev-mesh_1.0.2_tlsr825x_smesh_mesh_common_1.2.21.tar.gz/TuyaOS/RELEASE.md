# V1.0.0 - 2022/2/22

## 概述

涂鸦 TuyaOS BLE Mesh SDK 1.0.0 版本，为首次 release 版本。

本次新增的功能有：

* 支持涂鸦 mesh 配网(支持标准 mesh provision 与 Tuya fast provision )
* 支持所有 mesh 品类产品
* 支持外设测试（GPIO、PWM、ADC、IIC、SPI、Watchdog等）
* 支持OTA

更多信息详见文档《TuyaOS_BLE_Mesh_SDK_User_Guide_Tlsr825x》。

## 问题摘要

错误或增强功能的简短描述，暂无。

## 重现步骤

发现错误后的步骤如下，暂无。

## 解决方法

为修复错误所做的修改的简要说明，暂无。

## 影响

受更改影响的用户或功能所需的特定操作列表，暂无。