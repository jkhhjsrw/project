# TuyaOS BLE Mesh Developer Guide

## 概述

智能设备厂商计划对接涂鸦智能App / 涂鸦云平台，可以基于低功耗蓝牙组网技术BLE Mesh（Bluetooth Low Energy Mesh，低功耗蓝牙Mesh）来实现设备与App、网关的数据通信，从而获得连接涂鸦云的能力。

从技术角度看，目前涂鸦智能平台提供的对接方式有以下几种：

- 零代码开发：1颗芯片，又称作免开发方案，代码完全由涂鸦开发，客户通过平台进行配置；
- 低代码开发：2颗芯片，MCU（芯片1，客户开发）+ 模组（芯片2，涂鸦开发）；
- 多代码开发：1颗芯片，SDK（Software Development Kit，软件开发包）对接，又称作 SoC 方案，涂鸦提供支持基础通信能力的 SDK，客户实现具体的应用开发，需要客户具备一定的开发能力，该方案灵活性高。

本文档主要介绍了基于 TuyaOS BLE Mesh SDK 的 Demo。

用户可以基于 TuyaOS BLE Mesh SDK 开发自己的应用程序。

### 相关文档

蓝牙 mesh 协议：[Specifications – Bluetooth® Technology Website](https://www.bluetooth.com/specifications/specs/?status=active&show_latest_version=0&show_latest_version=1&keyword=mesh&filter=)

Tuya 协议：[蓝牙 Mesh 标准协议接入-TuyaOS-涂鸦开发者](https://developer.tuya.com/cn/docs/iot-device-dev/tuuya-zigbee-door-lock-docking-access-standard?id=K9ik5884f3in9)
（注：并非 Tuya 私有协议，而是基于 mesh 的标准在设备信息获取以及使用方面的协议指导）

Tuya 内部完整协议：[SIG MESH protocol](https://wiki.tuya-inc.com:7799/page/43049142)

### 概念解释

为了降低开发门槛，对一些常见的概念进行说明，更多概念说明详见：链接。

#### Mesh组网

蓝牙 Mesh 是基于 BLE 4.0 协议基础上实现的组网协议，并在蓝牙的 37/38/39 广播信道上进行通信。

同时受限于蓝牙广播的数据长度Mesh最底层的数据包长度也很短，但是 Mesh transport 层支持对上层的长数据进行分包，但是分包会增加发包的耗时。

#### Mesh数据包

我们目前常用的 mesh 控制数据包类型为 Access message。

Access message 分为 unseq acc / seq acc；

1. unseq acc 即 不分包 access 数据，最大长度为15，减去 MIC(4) 最大可以 11Byte。11Byte 里包括 opcode，即在用 vendor model 发送数据时，opcode 长度为3，即 data 最大为 8.

2. seq acc 即分包 access 数据，单包最大长度为12，即总长度为 12\*n，n为分包数。12\*n 中包括 MIC 4Byte)，即用户数据为 12\*n-4，再减掉 opcode 长度才为实际的用户数据长度 即： 12\*n - 4 - opcode_len。如果对于使用 vendor model 则分包数为 n = (data_len + 7)/12，对 n 取整。

在使用数据包很短的控制命令时，命令的成功率与到达的一致性都很优秀，例如：开关命令、照明的调光命名、传感器的数据上报等。所以建议数据命令长度较长的控制方式时建议不要选择 Mesh 方案，否则不仅无法发挥其优势而且有可能会出现数据延迟与丢包等问题。

#### 洪泛式网络

蓝牙 Mesh 属于一种低速率的洪泛式组网技术，网络内的节点如果具备转发能力在收到同一个网络的消息后，如果消息为可转发的消息则会将消息继续广播出去，以此达到一条 Mesh 数据能在整个Mesh网络内快速的传递。

洪泛式的组网有它的优势也有劣势，优势在于节点能够快速响应、到达成功率高、网络健壮性好等。劣势在于容易产生网络风暴，多条消息并发时网络内碰撞大，消息的到达率与响应速度就会下降。

#### TTL

TTL 指的是一条广播包可被转发次数，在每条的 mesh 广播包中都会存在，占用 7bit。对于 TTL 的值有以下解释：

• 0 = has not been relayed and will not be relayed
• 1 = may have been relayed, but will not be relayed
• 2 to 126 = may have been relayed and can be relayed
• 127 = has not been relayed and can be relayed

节点间通信为广播通信没有特定的路径，relay 节点收到的广播包只要 TTL 值不为 0 这条广播包就可以被继续转发，同时将广播包中的 TTL 减一。

#### SEQ

SEQ 全称 sequence num，每包的序列号。mesh 的每一包里都有一个长度为 3 个字节的序列号。对于同一个设备在发送 mesh 数据时，这个序列号必须是累加的。

同时每个 mesh 设备内部都有一张 SEQ 缓存表，用来缓存接收到的mesh数据包的源地址（src_addr）和其最新的 SEQ，这张表只存放在 RAM（掉电丢失）中。在每收到一个 mesh 数据包时都要去表里去查询，收到的SEQ是否大于缓存表同一个源地址的 SEQ，如果小于等于则认为次数据包为重传包或者不合法数据包，同时丢弃此数据包。

#### Mesh角色

Mesh Provisioner：配网者节点，例如：涂鸦智能 APP（手机）、蓝牙网关；
Relay node：转发节点，Mesh 网络中的长供电节点，可以转发网络内的消息；
Proxy node：代理节点，可以被手机 GATT 连接的节点，手机通过连接代理节点来发送或者接收 mesh 网络的数据来控制整个网络的节点；
LPN node：低功耗节点，会定期的休眠与唤醒，来降低自身的功耗；
Friend node：配合 LPN node 工作的朋友节点，当 LPN 节点休眠时，替其缓存数据，LPN 节点唤醒时再将数据发给它。

目前 Tuya 的设备默认都具备 relay、proxy 能力，目前 LPN 与 Friend 特性未使用。

#### Mesh密钥

Mesh Profile 规范定义了两种类型的密钥：应用程序密钥（AppKey）和网络密钥（NetKey）。NetKeys 用于网络层的通信加密，只有 NetKey 保持一致设备所发出的数据才可以被同一个Mesh网络内的节点进行传输。AppKeys 用于上层传输层的通信加密，只有AppKey保持一致，节点间通信发送的数据才可以被解密成应用数据。这两种类型的密钥在 mesh 节点之间是统一的，只有两个密钥保持一致才能进行通信。

除了上述两种密钥外还有一种设备密钥（DevKey），它是每个节点唯一的特殊应用程序密钥，即一机一密，只有节点和配网者知道，用于配网者来配置节点通信加密。

#### 配网

Mesh Spec 规定的标准配网为 mesh 的 Provision 过程，实际设备从未配网到可以正常通信分为两个步骤：

1. Mesh Provision阶段
   
   配网节点通过扫描到未配网的 mesh 节点设备，然后通过连接（PB-GATT）或者广播（PB-ADV）与设备通信并发起配网，配网过程会先通过ECDH 协商生成 Public key，然后基于 Public key 将Mesh网络的密钥 Network key 下发给设备，同时协商生成设备密钥 Device key，到此设备 Provision 阶段完成。

2. Config Model 配置阶段
   
   接下来还需要通过 Network key 与 Device key 的加密将应用密钥 App key 下发给设备，同时对设备的 Model 绑定对应的应用密钥以及更新 Mesh 设备的 Network transmit 参数，到此设备的完成配网完成。后续所有的业务都可以通过这三个密钥加密完成。

配网者中有两种承载方式（详细可参考 Mesh Profile 1.0.1 中 5.2 章节）：

1. PB-ADV
   
   配网者通过广播直接与未配网的 mesh 节点通信进行配网过程。此种方式一般适用于网关类配网者，此类配网者可以保持一致或者周期性 scan 空中的广播数据以及发送广播数据来做到与网络内节点通信。

2. PB-GATT
   
   配网者通过 GATT 连接的方式与未配网的 mesh 节点进行连接后通过连接通道进行配网。一般应用于手机 App 此类的配网者。手机 App 一般无法保持长时间的 scan 能力，所以无法直接接收Mesh网络的消息，所以需要通过 GATT 连接未配网的设备进行通信。

#### 重置

指的是设备通过重置从已配网状态恢复到未配网状态的动作。

使用 Tuya 基线开发的设备具备误重置恢复的能力，即设备被非人为或者错误的人为操作导致设备变为未配网状态，如果超时未配网、上电或者指定方式（应用自由定义）设备则可以恢复到重置前的网络中。

#### Mesh category

Mesh 产品能力值，用于区分设备的通信类型，依据设备的能力值将 Tuya 标准 DP 点转换为 SIG mesh model 命令进行通信。

具体能力值可以参考：[TuyaOS_BLE_Mesh_Application_Guide](TuyaOS_BLE_Mesh_Application_Guide.md)

内网可以参考：3.1.2 SIG MES 产品能力值-嵌入式知识库 (tuya-inc.com)

#### 其他名词

| **名词**    | **说明**                                                                                                                                                             |
| --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| PID       | 即产品 ID（Product ID），描述一类产品功能（DP）的集合。在 [涂鸦 IoT 平台](https://iot.tuya.com/) 创建的每一个产品都会产生一个唯一的产品编号，关联了产品具体的功能点、App 控制面板、出货信息等所有跟这个产品相关的信息。                              |
| MAC       | MAC 地址一般采用 6 字节（48bit），48bit 都有其规定的意义，前24位是由生产网卡的厂商向IEEE申请的厂商地址，后 24 位由厂商自行分配，这样的分配使得世界上任意一个拥有 48 位 MAC 地址的网卡都有唯一的标识。对于接入 Tuya 体系的 mesh 设备，都必须要使用 Tuya 分配的 MAC 地址。 |
| 设备解绑      | 设备解绑指的是手机 App 上通过手机蓝牙或者网关给设备发送重置命令，使设备恢复为未配网状态。                                                                                                                    |
| 本地重置      | 本地重置指的是设备通过本地按键或者多次快速上下电等方式自动脱离 mesh 网络恢复为未配网的状态。                                                                                                                  |
| 蓝牙连接      | 蓝牙连接仅表示蓝牙设备链路层的状态为连接状态。                                                                                                                                            |
| 蓝牙广播      | 蓝牙广播仅表示蓝牙设备链路层的状态为广播状态。                                                                                                                                            |
| mesh配网状态  | 指的是未配网的蓝牙mesh设备不断向控制发送未配网广播包的一种状态，此时 App 或者网关可以扫描到设备的未配网广播，从而对设备发起配网。                                                                                              |
| 本地在线      | 指的是当前 App 通过手机蓝牙与 mesh 网络建立连接，并可以控制 mes h网络内的所有设备。此时设备便是处于本地在线的状态。                                                                                                 |
| 网关在线      | 指的是当前网关在 mesh 网络中能够通过心跳检测到设备正常并处于可控制状态。此时的设备便是处于本地在线的状态。                                                                                                           |
| 本地在线/网关在线 | 设备可以同时支持本地在线与网关在线，即此时 App 可以通过手机蓝牙控制设备或者网关链路控制设备，目前 Tuya App 的策略为优先走网关链路控制。                                                                                        |

### 产品

#### 设备模型

设备品类根据 mesh_category 区分，参考[TuyaOS_BLE_Mesh_Application_Guide](TuyaOS_BLE_Mesh_Application_Guide.md)

##### 照明品类

照明类设备，是使用 SIG mesh 标准 model 最多的，DP 点与 mesh opcode 的对应规则如下：

element cnt：1

| DP ID | DP功能  | Model                    | Opcode                                                                                                              | 备注                                                                                                                                                                 |
| ----- | ----- | ------------------------ | ------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1     | 开关    | Generic OnOff Model      | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status                     | -                                                                                                                                                                  |
| 2     | 模式    | Tuya Vendor Model        | Vendor read <br> Vendor write <br> Vendor write unack <br> Vendor data                                              | 用于白光彩光模式切换                                                                                                                                                         |
| 3     | 亮度    | Light Lightness Model    | Light lightness get <br> Light lightness set <br> Light lightness set unack <br> Light lightness status             | SIG MESH 数据默认范围：0-65535                                                                                                                                            |
| 4     | 色温    | Light CTL Tempture Model | Light ctl tempture get <br> Light ctl tempture set <br> Light ctl tempture set unack <br> Light ctl tempture status | SIG MESH 数据默认范围：800-20000                                                                                                                                          |
| 5     | 颜色    | Light HSL Model          | Light hsl get <br> Light hsl set <br> Light hsl set unack <br> Light hsl status                                     | 通信使用 HSL 模型，Tuya DP 点为 HSV 模型，需要转换                                                                                                                                 |
| 6     | 情景    | Tuya Vendor Model        | Vendor read <br> Vendor write <br> Vendor write unack <br> Vendo data                                               | DP 数据，情景模式数据经过特殊压缩处理，降低数据长度                                                                                                                                        |
| 7     | 音乐    | Tuya Vendor Model        | Vendor read <br> Vendor write <br> Vendor write unack <br> Vendo data                                               | DP 数据，音乐灯数据经过特殊压缩处理，降低数据长度                                                                                                                                         |
| 其他    | 其他 DP | Tuya Vendor Model        | Vendor read <br> Vendor write <br> Vendor write unack <br> Vendo data                                               | 其他 DP 点数据均采用 [蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)处理 |

##### 电工品类

电工类设备也是较为特殊的，由于存在多路的开关，设备需要具备多个 element。

| DP ID | DP功能  | Model               | Opcode                                                                                          | element index | 备注                                                                                                                                                                 |
|:-----:|:-----:|:-------------------:|:----------------------------------------------------------------------------------------------- |:-------------:|:------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 1     | 开关1   | Generic OnOff Model | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status | 0             | 第1路设备的开关控制与状态                                                                                                                                                      |
| 2     | 开关2   | Generic OnOff Model | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status | 1             | 第2路设备的开关控制与状态                                                                                                                                                      |
| 3     | 开关3   | Generic OnOff Model | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status | 2             | 第3路设备的开关控制与状态                                                                                                                                                      |
| 4     | 开关4   | Generic OnOff Model | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status | 3             | 第4路设备的开关控制与状态                                                                                                                                                      |
| 5     | 开关5   | Generic OnOff Model | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status | 4             | 第5路设备的开关控制与状态                                                                                                                                                      |
| 6     | 开关6   | Generic OnOff Model | Generic onoff get <br> Generic onoff set <br> Generic onoff set unack <br> Generic onoff status | 5             | 第6路设备的开关控制与状态                                                                                                                                                      |
| 其他    | 其他 DP | Tuya Vendor Model   | Vendor read <br> Vendor write <br> Vendor write unack <br> Vendo data                           | 0             | 其他 DP 点数据均采用 [蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)处理 |

##### 其他类与透传类

除照明品类与电工品类之外的产品，均采用 Vendor 透传处理。所以能力值中大小类只是用来做相关记录，无特殊的品类处理。

| DP ID | DP功能  | Model               | Opcode                                                                | element index | 备注                                                                                                                                                                 |
|:-----:|:-----:|:-------------------:|:--------------------------------------------------------------------- |:-------------:|:------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| All   | 所有 DP | Tuya Vendor Model   | Vendor read <br> Vendor write <br> Vendor write unack <br> Vendo data | 0             | 其他 DP 点数据均采用 [蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)处理 |
| 无     | 无     | Generic OnOff Model | Generic onoff get <br/>Generic onoff status                           | 0             | 对于长供电设备，需要支持 Generic OnOff Model， <br>Generic onoff get 与 Generic onoff status 命令用作心跳， <br/>设备如果没有开关类状态， <br/>则此处 Generic onoff status 可以回复默认值为 1 的状态。             |

## 环境搭建

### 搭建硬件环境

硬件环境跟芯片平台完全相关，请参阅《TuyaOS_BLE_Mesh_Platform_xxxx》文档

### 搭建软件环境

部分软件环境跟芯片平台无关，在该文档中统一介绍，其他软件环境跟芯片平台相关，请参阅《TuyaOS_BLE_Platform_xxxx》文档

#### [Tuya Wind IDE](https://developer.tuya.com/cn/docs/iot-device-dev/Development-Tools?id=Kb0vhc1zz50dk)

前往 [Python 官网](https://www.python.org/downloads/) 下载 3.6~3.8 的版本进行默认安装。

注意：windows 下安装完 python 后在安装路径下默认是 python.exe，需要复制一份并重命名为 python3.exe（如果 python3.exe 已存在请忽略该步骤）。

![image-20211229171340283](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229171340283.png)

验证

![image-20211229171351181](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229171351181.png)

前往 [Vscode 官网](https://code.visualstudio.com/download) 下载最新的版本，并进行安装。

非常建议安装以下Vscode插件：

![image-20211231113746244](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211231113746244.png)

![image-20211231113912246](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211231113912246.png)

安装完成 Vscode 后在插件栏搜索 `Tuya Wind IDE` 并进行安装，安装完成后进行账号登录（同涂鸦 IoT 平台账号），如果没有账号，请前往 [涂鸦 IoT 平台](https://iot.tuya.com/) 进行账号注册。

![image-20220411150042599](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20220411150042599.png)

登录完成后，请参考 `开发框架` 进行接下来的步骤。

#### 开发框架

开发框架即开发包

##### 获取

在 Vscode 下登录 `Tuya Wind IDE` 账号，然后选择 `创建新框架` 进行开发包选择

![image-20220411150243137](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20220411150243137.png)

选择到合适的开发包后点击确认并开始拉取，拉取完成即可进行相关功能的开发。

![image-20220411150522556](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20220411150522556.png)

等待开发框架拉取完成

![image-20220411150607013](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20220411150607013.png)

##### 编译

找到 Demo 所在目录，在该目录上右键选择 `Build Project` 

![image-20211229171508492](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229171508492.png)

手动输入版本号（该版本号即为编译生成的固件版本号，mesh sdk 需要使用 2 位版本号，例如 **“1.1”**）

![image-20211229171519740](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229171519740.png)

等待编译成功

![image-20211231114535344](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211231114535344.png)

#### 使用第三方开发工具

使用 Keil 等第三方开发工具编译前，必须要使用 Vscode 进行一次编译。

打开 Keil 等第三方开发工具前，首先关闭Vscode，防止两个软件发生冲突。

在以下目录找到 Keil  等第三方开发工具的工程文件，打开后可以进行正常的编译和调试。

![image-20211231144043789](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211231144043789.png)

#### 添加文件

`切勿使用Keil进行源文件和头文件的添加操作`

在如下目录下添加源文件

![image-20211231152446129](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211231152446129.png)

在如下目录下添加头文件

![image-20211231152805277](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211231152805277.png)

源文件/头文件添加完成后，至少使用 Vscode 进行一次代码编译，之后可继续使用 Vscode 或者切换到 Keil 等第三方开发工具进行代码调试工作。

#### 注意

1. 第一次编译必须要使用 Vscode 进行编译，脚本会自动构建编译环境，之后你可以打开 IAR 或者 Keil 等第三方开发工具进行调试；

2. Vscode 下的脚本会递归遍历 tuyaos_demo_ble_peripheral 文件夹，自动添加该文件下所有的源文件和头文件到编译环境；

3. Vscode 在每次编译前都会重新构建编译环境，以下操作要特别注意：
- 在使用 IDE 编译的时请关闭 IAR 或者是 Keil 等第三方开发工具，否则可能会导致文件占用的问题；

- 在使用 IAR 或者 Keil 等第三方开发工具进行调试的时候，禁止手动添加头文件或者是源文件到工程项目中；

## 开发软件

### 软件架构

![image-20220407115202604](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20220407115202604.png)

### sample

#### app_common

应用 Demo，开发者可以在此 Demo 基础上修改，增加自己的业务功能。文件中实现了 Mesh 工程必须组件的相关调用，谨慎删除。

### 软件运行流程

![image-20211229171646000](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229171646000.png)

## 组件

### tal_bluetooth

实现BLE蓝牙的基本接口，以及BLE Mesh的操作接口。包括数据的收发，网络状态的配置，节点信息的配置等功能。

包括tal_bluetooth、tal_bluetooth_mesh_device、tal_bluetooth_mesh_provisioner等文件的功能实现。

### tal_driver

实现了外设驱动的使用接口，包括GPIO、ADC、Flash、I2C、PWM、RTC、SPI、UART、Watchdog等。

### tal_mesh_factory_test

实现授权产测功能，包括授权 RSSI 测试与整机测试扫描产测信标功能。

### tal_gpio_test

实现涂鸦产测模块GPIO测试功能。

### tal_ble_uart_common

实现串口数据解析功能。

### tal_ble_mbedtls

包括md5、aes、sha256等软件加密算法的实现。

### tal_oled

实现驱动OLED屏幕功能。

### tal_util

实现通用的工具接口。

### tal_sdk_test

实现测试功能。

## 烧录固件

烧录固件跟芯片平台完全相关，请参阅《TuyaOS_BLE_Platform_xxxx》文档

## 授权

详见《[TuyaOS BLE SDK Product Test](https://registry.code.tuya-inc.top/document/platform/-/blob/main/_%E6%B1%87%E6%80%BB/04_%E4%BA%A7%E6%B5%8B/TuyaOS_BLE_SDK_Product_Test.md)》，该文档位于doc文件夹下。

## 测试

#### 体验

授权结束后，即成功激活涂鸦BLE设备。

此时可在App Store下载 `涂鸦智能` App，登录后 `添加设备` / 点击 `右上角` → `添加设备` 

![image-20211231145241481](https://images.tuyacn.com/fe-static/docs/img/d22d6359-e2c9-4ae6-9880-59bce87ebcf1.png)

设备添加完成后如下图所示：

![image-20211231145506556](https://images.tuyacn.com/fe-static/docs/img/97c0b42e-e98e-48c6-a170-77453af630d9.jpg "aa")

此时可通过 `涂鸦智能` App 控制 BLE Mesh 设备。

### 测试上位机

#### 使用范围

TuyaOS BLE SDK，用于蓝牙协议和外设功能的验证和测试。

#### 获取方式

[下载地址](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/logic/logic.exe)

#### 基本信息

通信方式：串口

波特率：默认 9600

#### 使用步骤

绿色软件，无需安装，解压至一个**单独文件夹**中双击打开即可。

默认界面

![image-20211229172046966](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172046966.png)

串口设置，可关闭打开串口设置

关闭

![image-20211229172059627](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172059627.png)

打开

![image-20211229172109380](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172109380.png)

调试 - 调试信息

可关闭打开调试信息（串口指令）

关闭

![image-20211229172129374](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172129374.png)

打开

![image-20211229172138937](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172138937.png)

设置

![image-20211229172147784](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172147784.png)

恢复出厂设置：对设备发送恢复出厂设置的命令

打开声音：打开声音，进行必要的声音提示

显示行数：前台Log的最大显示行数

定时发送时间：指令定时发送时间，单位ms

![image-20211229172158480](https://myphotos-1257188211.cos.ap-shanghai.myqcloud.com/img/image-20211229172158480.png)

TuyaOS@无线二：了解TuyaOS

最新版本：获取最新版本

## OTA

### 协议

参考《Tuya BLE Communication Protocol》中8.13\~8.18小节。

Mesh升级协议与BLE单点协议相同，但是因为Mesh没有BLE绑定配对的流程，所以使用的秘钥不同采用Mesh设备的device key来加密，其余的流程以及设备端GATT服务的配置则与BLE单点相同。

### 流程

![](https://images.tuyacn.com/fe-static/docs/img/7c37c369-b86b-4d2c-a781-6e488f065dd2.png)

### 特点

1. 双备份OTA（Tlsr825x）

固件支持0x00000-0x2FFFF与0x30000-0x5FFFF两个代码区域运行，在上电时bootloader会根据两个代码区的有效性来决定运行哪一个区域的固件，如果两个区域都是有效的则运行第一个区域的代码。

2. 支持断点续传

3. 支持版本校验

### 相关代码

#### 组件

tal_mesh_gatt_ota

#### TKL

使用 tkl_ota、tkl_flash相关接口。

## 默认参数

### 串口参数

串口号：UART0（此处指代TAL层的UART0，具体引脚请参考硬件说明）

波特率：9600

最大数据长度：≥200字节

### 蓝牙参数

#### BLE参数

默认GATT Proxy广播间隔：160ms(±30ms)

默认连接间隔：20\~30ms

OTA连接间隔：15\~30ms

默认连接超时：4000ms

默认MTU ：247

#### Mesh参数

默认Network transmit cnt：4

默认Network transmit step：1

默认Relay retransmit cnt：1

默认Relay retransmit step：0

默认TTL：8

Mesh secure network beacon周期：10s

### 通信距离

室内无遮挡无干扰：≥40m

室外无遮挡无干扰：≥110m

### OTA时间

不低于60s/100kB

## 注意事项
