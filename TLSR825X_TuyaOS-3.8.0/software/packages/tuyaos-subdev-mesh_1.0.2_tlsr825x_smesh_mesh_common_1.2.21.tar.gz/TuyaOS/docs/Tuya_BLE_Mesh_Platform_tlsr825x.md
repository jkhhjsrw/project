# TuyaOS BLE Mesh Platform tlsr825x

## 搭建环境

### 芯片手册

芯片手册下载地址：[TLSR825x Series - Telink wiki](http://wiki.telink-semi.cn/wiki/chip-series/TLSR825x-Series/)

### 开发板

#### 核心板

使用 BT3L 模块
![](https://images.tuyacn.com/fe-static/docs/img/671fb058-6db8-4714-9a5d-37fb36b92868.jpg)

#### 底板

![](https://images.tuyacn.com/fe-static/docs/img/33d549ed-33e9-4e3b-ab93-e9575f6c46c0.jpg)

### 外设

#### GPIO

Tuya OS 中操作指定的 IO 要使用 IO 序号作为入参进行操作，对于 Tlsr825x 平台，GPIO 序号与实际的 IO 对应列表参考下方表格。

|     |     |     |     |     |     |     |     |     |     |
| :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
| **序号** | **GPIO** | **序号** | **GPIO** | **序号** | **GPIO** | **序号** | **GPIO** | **序号** | **GPIO** |
| 0    | PA0  | 8    | PB0  | 16   | PC0  | 24   | PD0  | 32   | PE0  |
| 1    | PA1  | 9    | PB1  | 17   | PC1  | 25   | PD1  | 33   | PE1  |
| 2    | PA2  | 10   | PB2  | 18   | PC2  | 26   | PD2  | 34   | PE2  |
| 3    | PA3  | 11   | PB3  | 19   | PC3  | 27   | PD3  | 35   | PE3  |
| 4    | PA4  | 12   | PB4  | 20   | PC4  | 28   | PD4  | ﻿     | ﻿     |
| 5    | PA5  | 13   | PB5  | 21   | PC5  | 29   | PD5  | ﻿     | ﻿     |
| 6    | PA6  | 14   | PB6  | 22   | PC6  | 30   | PD6  | ﻿     | ﻿     |
| 7    | PA7  | 15   | PB7  | 23   | PC7  | 31   | PD7  | ﻿     |      |

#### UART

该平台同时只支持1个串口UART0，Tuya OS中默认使用下表中的引脚。如果要使用其他引脚作为UART可参考芯片手册自由配置。

| **UART**  | **功能** | **引脚** |
| :-: | :-: | :-: |
| UART0 | TX | PB1 |
| UART0 | RX | PB7 |

#### SPI

该平台有两组SPI接口可使用，同时只能使用其中一组。Tuya OS中SPI初始化默认使用SPI1。

| **SPI** | **功能** | **引脚** |
|---------|----------|----------|
| SPI1    | CS       | PD6      |
| SPI1    | CLK      | PA4      |
| SPI1    | SDI      | PA3      |
| SPI1    | SDO      | PA2      |
| SPI2    | CS       | PD2      |
| SPI2    | CLK      | PD7      |
| SPI2    | SDI      | PB6      |
| SPI2    | SDO      | PB7      |

#### I2C

该平台有4组I2C接口可使用，同时只能使用其中一组。Tuya OS中I2C初始化默认使用I2C0。

| **IIC** | **功能** | **引脚** |
|---------|----------|----------|
| IIC0    | SCL      | PC3      |
| IIC0    | SDA      | PC2      |
| IIC1    | SCL      | PC0      |
| IIC1    | SDA      | PC1      |
| IIC2    | SCL      | PB6      |
| IIC2    | SDA      | PD7      |
| IIC3    | SCL      | PA3      |
| IIC3    | SDA      | PA4      |

#### PWM

此平台最多支持 6 路 PWM 输出，PWM 初始化后默认的引脚如下表所示。如果需要修改 PWM 通道所映射的 GPI O引脚，则需要调用 tkl_pwm_mapping_to_gpio 重新映射 GPIO 为 PWM 功能。

| **通道** | **引脚** |
|----------|----------|
| 0        | PC2      |
| 1        | PC3      |
| 2        | PD4      |
| 3        | PD2      |
| 4        | PB4      |
| 5        | PB5      |

#### ADC

此平台总共支持 10 个引脚的 ADC 复用功能，详细见下表。

| **通道** | **引脚** |
|----------|----------|
| 0        | PB0      |
| 1        | PB1      |
| 2        | PB2      |
| 3        | PB3      |
| 4        | PB4     |
| 5        | PB5      |
| 6        | PB6      |
| 7        | PB7      |
| 8        | PC4      |
| 9        | PC5      |


## 烧录固件

### 连线说明

烧录器 SWM 引脚接模块 SWS 引脚。

### 固件说明

对于 tlsr825x 平台，生产固件与 OTA 固件都为同一个 `.bin` 格式的固件

### 烧录方式1

可以将固件上传至涂鸦 IOT 平台使用涂鸦烧录授权工具，详见《[TuyaOS BLE SDK Product Test](https://registry.code.tuya-inc.top/document/platform/-/blob/main/_%E6%B1%87%E6%80%BB/04_%E4%BA%A7%E6%B5%8B/TuyaOS_BLE_SDK_Product_Test.md)》。

### 烧录方式2

使用 telink 官方 DBT 工具进行烧录，具体可以参考 telink 官方指导：[Burning and Debugging Tools for all Series](http://wiki.telink-semi.cn/wiki/IDE-and-Tools/Burning-and-Debugging-Tools-for-all-Series/)。


## 平台特性

### 存储

Flash：512KB

RAM：48KB

![](https://images.tuyacn.com/fe-static/docs/img/156fbafc-4110-4f81-9af7-eec5d230aadc.png)

图 Tlsr825x mesh SDK flash map

Tlsr825x 平台 mesh 的 SDK 采用双备份（乒乓）升级方案，固件分为两片区域。第一片区域为 0x00000 \- 0x2FFFF，第二片区域为0x40000 – 0x6FFFF。在上电时 bootloader 会根据两个代码区的有效性来决定运行哪一个区域的固件，如果两个区域都是有效的则运行第一个区域的代码。

留给用户区的区域为 0x78000 – 0x7FFFF。目前 Tuya OS 中使用了 NV 组件，底层占用两个扇区，即应用可以使用 NV 组件的 MODULE_2 与 MODULE_3，除此之外留给应用可自由使用的为 0x7D000 – 0x7EFFF。


### 功耗

Mesh设备由于需要保持scan扫描空中广播包，所以正常工作状态中无法进入低功耗。所以设备的功耗会维持在一个较高的水平，跟SoC的主频以及设备的发射功率有关，但是如果对于正常工作状态发包是较少的，不同发射功率引出的功耗差异对比 SoC 正常运行以及 scan 的功耗是很小的，测试差异基本体现不出来。

![](https://images.tuyacn.com/fe-static/docs/img/7cd2a241-5595-4d7d-9b98-a654242fe7ff.png)

图 48M主频10.5dBm发射功率

![](https://images.tuyacn.com/fe-static/docs/img/f38b85da-bc2a-4bba-81bb-1ee11b9507cd.png)

图 16M主频10.5dBm发射功率
