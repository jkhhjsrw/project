# TuyaOS BLE Mesh Platform phy6222

## 搭建环境

### 芯片手册

芯片手册下载地址：[PHYPLUS wiki](http://wiki.phyplusinc.com/doku.php?id=menu:phy62_series:phy6222)

### 开发板

#### 核心板

使用 BP3L 模块
![](https://images.tuyacn.com/fe-static/docs/img/11534ebe-b803-4471-9853-234adae262bf.jpg)

#### 底板

![](https://images.tuyacn.com/fe-static/docs/img/2094ba98-2272-4425-a40d-a54ad74c8462.jpg)

### Keil环境

Keil 软件请自行安装（所有安装使用默认配置），此处不赘述。

安装期间若弹出安装驱动请选择 安装。

Keil 软件安装完成后请将 `UV4.exe`文件所在的目录添加到 windows 系统`环境变量`中，结果如下图所示：

例如：`TUYAOS_COMPILE_TOOL：D:\Program_Files\keil\UV4`

![](https://images.tuyacn.com/fe-static/docs/img/c6a595a5-aa42-495b-8629-0195ef0f0633.png)

添加的方式为新建环境变量，输入变量名`TUYAOS_COMPILE_TOOL`，与变量值（即`UV4.exe`所在路径）

![](https://images.tuyacn.com/fe-static/docs/img/d80135ee-52cf-42f5-9119-3829ce46613a.png)

### 外设

#### GPIO

Tuya OS 中操作指定的 IO 要使用 IO 序号作为入参进行操作，对于 Tlsr825x 平台，GPIO 序号与实际的 IO 对应列表参考下方表格。

|     |     |     |     |     |     |     |     |     |     |
| :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
| **序号** | **GPIO** | **序号** | **GPIO** | **序号** | **GPIO** | **序号** | **GPIO** | **序号** | **GPIO** |
| 0    | GPIO_P00  | 8    |   不支持   | 16   | GPIO_P16  | 24   | GPIO_P24  | 32   | GPIO_P32  |
| 1    | GPIO_P01  | 9    | GPIO_P09  | 17   | GPIO_P17  | 25   | GPIO_P25  | 33   | GPIO_P33  |
| 2    | GPIO_P02  | 10   | GPIO_P10  | 18   | GPIO_P18  | 26   | GPIO_P26  | 34   | GPIO_P34  |
| 3    | GPIO_P03  | 11   | GPIO_P11  | 19   | GPIO_P19  | 27   | GPIO_P27  |      |      |
| 4    |   不支持   | 12   |   不支持   | 20   | GPIO_P20  | 28   |   不支持   |      |      |
| 5    |   不支持   | 13   |   不支持   | 21   |   不支持   | 29   |   不支持   |      |      |
| 6    |   不支持   | 14   | GPIO_P14  | 22   |   不支持   | 30   |   不支持   |      |      |
| 7    | GPIO_P07  | 15   | GPIO_P15  | 23   | GPIO_P23  | 31   | GPIO_P31  |      |      |

#### UART

该平台同时只支持2个串口UART0，Tuya OS中默认使用下表中的引脚。如果要使用其他引脚可调用 `OPERATE_RET tkl_uart_mapping_to_gpio(UINT_T port_id, UINT32_T uart_tx, UINT32_T uart_rx)` 重新映射。

| **UART**  | **功能** | **引脚** |
| :-: | :-: | :-: |
| UART0 | TX | GPIO_P09 |
| UART0 | RX | GPIO_P10 |
| UART1 | TX | GPIO_P31 |
| UART1 | RX | GPIO_P32 |

#### SPI

该平台目前只能使用其中一组 SPI，默认引脚如下表，可调用 `OPERATE_RET tkl_spi_mapping_to_gpio(UINT32_T port, UINT32_T sclk_pin, UINT32_T sdo_pin, UINT32_T sdi_pin, UINT32_T cs_pin)` 重新映射 IO 功能。。

| **SPI** | **功能** | **引脚** |
|---------|----------|----------|
| SPI1    | CS       | GPIO_P34 |
| SPI1    | CLK      | GPIO_P31 |
| SPI1    | SDI      | GPIO_P33 |
| SPI1    | SDO      | GPIO_P32 |

#### I2C

该平台有2组I2C接口可使用。Tuya OS中I2C初始化默认使用I2C0，默认引脚如下表，可调用 `OPERATE_RET tkl_iwc_mapping_to_gpio(UINT_T port, UINT32_T sda, UINT32_T scl)` 重新映射 IO 功能。

| **IIC** | **功能** | **引脚** |
|---------|----------|----------|
| IIC0    | SCL      | GPIO_P32      |
| IIC0    | SDA      | GPIO_P33      |
| IIC1    | SCL      | GPIO_P02      |
| IIC1    | SDA      | GPIO_P03      |

#### PWM

此平台最多支持 6 路 PWM 输出，PWM 初始化后默认的引脚如下表所示。如果需要修改 PWM 通道所映射的 GPI O引脚，则需要调用 `OPERATE_RET tkl_pwm_mapping_to_gpio(UINT32_T ch_id, UINT32_T gpio)` 重新映射 GPIO 为 PWM 功能。

| **通道** | **引脚** |
|----------|----------|
| 0        | GPIO_P31      |
| 1        | GPIO_P32      |
| 2        | GPIO_P26      |
| 3        | GPIO_P33      |
| 4        | GPIO_P34      |
| 5        | GPIO_P07      |

#### ADC

此平台总共支持 8 路普通 ADC 功能，详细见下表，但实际可用的只有部分。

| **通道** | **引脚** |
|----------|----------|
| 0        | 不支持      |
| 1        | 不支持      |
| 2        | GPIO_P11      |
| 3        | GPIO_P23      |
| 4        | GPIO_P24     |
| 5        | GPIO_P14      |
| 6        | GPIO_P15      |
| 7        | GPIO_P20      |
| 8        | 不支持      |


## 烧录固件

### 连线说明

芯片采用串口烧录方式，使用的串口为:

| **UART**  | **功能** | **引脚** |
| :-: | :-: | :-: |
| UART0 | TX | GPIO_P09 |
| UART0 | RX | GPIO_P10 |

### 固件说明

生产固件为 `.hexf` 格式，升级固件为 `.bin` 格式。

![](https://images.tuyacn.com/fe-static/docs/img/fbfbfbc4-2abf-45a9-8ff8-6b87ac72795b.png)

### 烧录方式1

可以将固件上传至涂鸦 IOT 平台使用涂鸦烧录授权工具，详见《[TuyaOS BLE SDK Product Test](https://registry.code.tuya-inc.top/document/platform/-/blob/main/_%E6%B1%87%E6%80%BB/04_%E4%BA%A7%E6%B5%8B/TuyaOS_BLE_SDK_Product_Test.md)》。

### 烧录方式2

使用奉加微官方上位机 `PhyPlusKit_v2.5.2a.exe` 进行烧录。

1.设备进入烧录模式

![](https://images.tuyacn.com/fe-static/docs/img/7cbe7158-4a26-479f-a9e8-310d7aa92e3d.png)

2.选择固件并烧录

![](https://images.tuyacn.com/fe-static/docs/img/df7eae83-d49d-4d67-ab01-f3a71ea57f4f.png)

3.烧录完成

![](https://images.tuyacn.com/fe-static/docs/img/c78f2b79-431f-4869-add7-dd9433f6f57d.png)


## 平台特性

### 存储

Flash：512KB

RAM：64KB

![](https://images.tuyacn.com/fe-static/docs/img/8b105a1f-c583-44ab-b818-d60c9b9f7b65.png)

图 PHY6222 mesh SDK flash map

PHY6222 采用 bootloader 的方式进行升级，升级过程中将固件存储到 0x4D000 - 0x7FFFF 区域，在重启后由 bootloader 将代码覆盖到 XIP 区域（即 0x9000 - 0x3BFFF）。

留给用户区的区域为 0x40000 – 0x4CFFF。目前 Tuya OS 中使用了 NV 组件，即可以使用 NV 组件的 MODULE_2 与 MODULE_3，除此之外留给应用可自由使用的为 0x45000 – 0x4CFFF。


### 功耗

Mesh设备由于需要保持scan扫描空中广播包，所以正常工作状态中无法进入低功耗。所以设备的功耗会维持在一个较高的水平，跟SoC的主频以及设备的发射功率有关，但是如果对于正常工作状态发包是较少的，不同发射功率引出的功耗差异对比 SoC 正常运行以及 scan 的功耗是很小的，测试差异基本体现不出来。

![](https://images.tuyacn.com/fe-static/docs/img/244d61d8-72cc-481d-8857-cec0a4db1355.png)

图 48M主频10.5dBm发射功率