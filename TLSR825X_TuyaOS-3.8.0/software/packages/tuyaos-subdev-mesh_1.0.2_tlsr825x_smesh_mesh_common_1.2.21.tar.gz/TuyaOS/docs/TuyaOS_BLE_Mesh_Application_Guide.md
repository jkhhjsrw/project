# TuyaOS BLE Mesh Application Guide

## 概述

此文档为 TuyaOS 应用开发指南，介绍了应用开发相关配置与策略。

## Demo处理

### LOG开启

默认 demo 中 log 是关闭的，可以在 `tuya_iot_config.h` 中修改实现 `#define ENABLE_LOG 1`，既可以使用 tal_log 组件中接口输出日志，已经打成 lib 的组件是没有日志的，如果有问题需要调试请联系涂鸦开发人员。

另外原厂 SDK 底层由于是源码开放，log 可以直接开启。 

1. tlsr825x 平台将 `app_mesh.h` 中 `LOG_FW_FUNC_EN`宏定义使能即可开启；
2. phy6222 平台将 `EM_platform.h`中 `PHY_LOG_EN`宏定义使能即可开启；

### SDK测试功能关闭

`tuya_iot_config.h` 中将 `#define TUYA_SDK_TEST 1`注释或者修改为 `#define TUYA_SDK_TEST 0`后即可关闭原有的串口上位机 SDK 测试功能，将会节省大量的 code size。

同时 tal_sdk_test 组件 `tal_mesh_sdk_test.c` 的代码可以用外设或者蓝牙等接口处理的参考。

## appconfig.json 配置

参考 apps/tuyaos_demo_mesh_node 的 demo 中的 appconfig.json 文件，为产品必须的配置。在 Build 时，脚本会将 json 中的配置信息转换为宏配置输出到 include/app_config.h 中供工程使用。

| 配置项名称 | 释义 | 备注 |
| --- | :-- | --- |
| hardware_version | 硬件版本号 | 可按照默认处理，目前 mesh 工程并未使用 |
| product_key | 产品信息 | 填充 Tuya IoT 平台上创建的 mesh 品类产品的 PID 或者固件 key(固件 key 方式较为特殊只允许 tuya 内部使用) |
| is_firmware_key | 产品信息类型 | product_key 填充 PID 则为 0，填充固件 key 则为 1 |
| mesh_category | mesh 设备能力值 | 参考下文 **mesh category** 章节 |
| need_publish_addr | 是否需要 publish addr | 本地联动条件设备使用，参考下文 **本地联动** 章节 |

## mesh category

mesh category 是 Tuya mesh 设备 UUID 中的重要组成部分，也是 APP 在控制时相关策略的依据。

### mesh category 组成与释义：

<table>
<thead>
  <tr>
    <th>　</th>
    <th colspan="3">Octet 1</th>
    <th colspan="2">Octet 0</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td>类型</td>
    <td>RFU</td>
    <td>设备类型</td>
    <td>RFU</td>
    <td>产品大类</td>
    <td>产品小类</td>
  </tr>
  <tr>
    <td>bit位</td>
    <td>bit15-bit14</td>
    <td>bit13-bit12</td>
    <td>bit11-bit8</td>
    <td>bit7-bit4</td>
    <td>bit3-bit0</td>
  </tr>
  <tr>
    <td>功能说明</td>
    <td>涂鸦内部使用</td>
    <td>1 = 标准类型<br>0 = 透传类型</td>
    <td>涂鸦内部使用</td>
    <td>产品大类例如照明、电工、传感等，具体见下表</td>
    <td>产品小类例如几路灯，几路插座等，具体见品类小类表</td>
  </tr>
</tbody>
</table>

参考 TuyaOS_BLE_Mesh_Developer_Guide.md 中 **产品** 章节，目前只有 **照明品类** 与 **电工品类** 设备在接收命令时使用到了标准 sig model 相关的命令，以及 **遥控器品类** 需要发送标准 sig model 命令，所以只有这三类产品的设备类型是标准类型，其余的均为透传类型。

照明类设备使用规范参考：[蓝牙 Mesh 照明设备接入规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-light-access-standard?id=K9pieafepp3q7)

电工类设备使用规范参考：[蓝牙 Mesh 多路开关接入规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-multiple-switch-access-standard?id=K9pj49qrwov8x)

透传型设备通信采用的是 vendor model，vendor model 的相关使用规范参考 [蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)

**注意：**默认所有长供电类设备，需要支持 Generic OnOff Model，**Generic onoff get** 与 **Generic onoff status** 命令用作心跳，设备如果没有开关类状态，则此处 Generic onoff status 可以回复默认值为 1 的状态。

### 产品大类表

| 产品类型 | 产品大类 |
| -- | -- |
| 照明类 | 0x01 |
| 电工类 | 0x02 |
| 传感类 | 0x04 |
| 遥控类 | 0x05 |
| 无线开关类 | 0x06 |
| 强电类传感类 | 0x07 |
| 强电类遥控类 | 0x08 |
| 家电健康类 | 0x09 |

### 产品小类表

#### 照明品类

| 灯类 | 能力值 |
| -- | -- |
| W | 0x1011 |
| CW | 0x1012 |
| RGB | 0x1013 |
| RGBW | 0x1014 |
| RGBCW | 0x1015 |

#### 电工品类

| 插座/开关 | 能力值 |
| -- | -- |
| 1路 | 0x1021 |
| 2路 | 0x1022 |
| 3路 | 0x1023 |
| 4路 | 0x1024 |
| 5路 | 0x1025 |
| 6路 | 0x1026 |

#### 低功耗传感品类

| 插座/开关 | 能力值 |
| -- | -- |
| 门磁 | 0x2041 |
| PIR | 0x2042 |
| 亮度 | 0x2043 |
| 温湿度 | 0x2044 |
| 水浸 | 0x2045 |
| 微波 | 0x2046 |

#### 低功耗遥控器品类

遥控器的控制是基于群组地址的控制方式，具体的策略参考下文 **遥控器控制** 章节。

| 支持的群组按键个数 | 能力值 |
| :-: | -- |
| 1 | 0x1051 |
| 2 | 0x1052 |
| 3 | 0x1053 |
| 4 | 0x1054 |

#### 无线开关品类

无线开关与遥控器的区别在于无线开关需要发送数据到网关来联动其他设备的动作，遥控器则是直接发送控制命令到被控设备。

| 按键数 | 能力值 |
| :-: | -- |
| 1 | 0x2061 |
| 2 | 0x2062 |
| 3 | 0x2063 |
| 4 | 0x2064 |

#### mesh vendor 透传规范
标准 model 无法实现的 DP 通信，则通过 vendor model 实现，具体可参考：[蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)

## 低功耗处理

低功耗处理可直接使用 tkl 层接口，包括 tkl_sleep 与 tkl_wakeup。

代码示例：

```c
tkl_cpu_sleep_mode_set(1, TUYA_CPU_SLEEP); 	//设置休眠唤醒方式：TUYA_CPU_SLEEP - suspend 模式;TUYA_CPU_DEEP_SLEEP - 深度休眠模式，必须先设置不同模式支持唤醒源方式可能不同

TUYA_WAKEUP_SOURCE_BASE_CFG_T param;
param.source = TUYA_WAKEUP_SOURCE_GPIO;
param.gpio_param.gpio_num = TUYA_GPIO_NUM_26;
param.gpio_param.level = TUYA_GPIO_LEVEL_HIGH;
tkl_wakeup_source_set(&param);				//设置唤醒源：GPIO26 高电平唤醒

param.source = TUYA_WAKEUP_SOURCE_GPIO;
param.gpio_param.gpio_num = TUYA_GPIO_NUM_33;
param.gpio_param.level = TUYA_GPIO_LEVEL_LOW;
tkl_wakeup_source_set(&param);				//设置唤醒源：GPIO33 低电平唤醒

param.source = TUYA_WAKEUP_SOURCE_TIMER;
param.timer_param.mode = TUYA_TIMER_MODE_ONCE;
param.timer_param.ms = 10000;
tkl_wakeup_source_set(&param);				//设置唤醒源：定时 10s 后唤醒

tkl_cpu_allow_sleep();						//进入休眠
```

### 休眠模式

suspend 模式：设备进入休眠，唤醒之后程序从进休眠的位置继续跑，功耗相对深度休眠模式较高；

deep sleep 模式：深度休眠模式，设备功耗最低的模式，唤醒之后设备需要从头开始启动与初始化，并且注意此模式部分平台（PHY6222）只支持 GPIO 唤醒，不支持 timer 唤醒，要以接口返回值是否成功为准。

### 唤醒源

对于 mesh 设备，进入低功耗后一般要通过按键或者定时唤醒，按键支持高低电平唤醒，一般用于遥控器等低功耗产品使用。timer 唤醒则是定时唤醒，设备进休眠之后可延时一段时间自动唤醒，一般用于单火开关设备或者感应灯低功耗等设备。

## 本地联动

本地联动的实现方式为，条件设备向一个群组地址中发送数据，被控设备订阅这个群组地址，则可以实现条件设备与被控设备间的一对多，多对多的联动方式。

### need_publish_addr 含义

need_publish_addr 为条件设备使用，可以在配网阶段向 App 或者网关申请一个群组地址，作为自己固定的 publish 地址。

### 获取 publish addr 配置方式

1. 将 appconfig.json 中的 need_publish_addr 使能之后；
2. 需要在 `tuya_init_third()` 初始化函数中调用 `tal_mesh_fast_prov_enable(0);` 接口来关闭快速配网。（对于公版 **4.8.0** 及以上版本 APP 支持快速配网过程中分发 publish addr，则无需调用此命令）

通过上述两个操作后，设备就可以在配网阶段收到一个群组地址 addr 来作为自己的 publish 地址。实际设备可使用的 publish 地址为 addr - addr + 7 总共8个地址可用，默认使用第一个，有多路的要求时则可以使用多个 publish 地址。

### publish 地址下发

在配网后，App 或者网关会通过 vendor model 来下发这个群组地址，详细格式见下文：

**App 发送：**

opcode： 0xC9D007

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x86 |
| 数据长度 | 1 | 0x02 |
| 数据 | group addr(2 byte) | group_addr：设备的 publish 地址 |

**设备回复：**

opcode： 0xCDD007

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x86 |
| 数据长度 | 1 | 0x01 |
| 数据 | 1 | 0x00:success<br>0x01:fail |

## 遥控器控制

遥控器控制同样需要在配网时获取 publish 地址 addr。但是遥控器方式比较特殊，不同于本地联动方式。

### 获取 publish addr 配置方式

设备的能力值需要配置为遥控器品类的能力值。

需要在 `tuya_init_third()` 初始化函数中调用 `tal_mesh_fast_prov_enable(0);` 接口来关闭快速配网。（对于公版 **4.8.0** 及以上版本 APP 支持快速配网过程中分发 publish addr，则无需调用此命令）

在配网成功后，调用 `tal_group_addr_sub_list_get(0, 0x1000);`获取遥控器所订阅的群组，在获取到地址范围为 0xC000 - 0xFEFF 同时不等于 0xD000 的地址即为分配给遥控器的 publish addr。

### 与设备配对方式

如果遥控器有多个群组按键，则第一个按键发送的目的地址为 addr，第二个按键发送的目的地址为 addr + 1，以此类推。

遥控器与设备的绑定除了遥控器的 APP 面板中操作之外也支持本地的绑定，遥控器向 0xFFFF 广播地址中发送数据，所有的设备都可以接收到此数据并订阅数据中所带的群组地址，订阅此地址之后，遍与遥控器形成了绑定关系。（注意：为了防止设备的误操作，建议每个设备设置可绑定窗口，只有在一定操作后的时间内才处理此命令，不在窗口内则忽略，否则绑定操作将会作用于所有已配网已上电的设备。）

**遥控器与设备绑定协议如下：**

**遥控器 发送：**

opcode： 0xC9D007

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x81 |
| 数据长度 | 1 | 0x03 |
| 数据 | Cmd（1byte）+ Sub_addr(2byte) | Cmd:<br> 0x00：删除订阅（设备可选择是否执行）<br>0x01：增加订阅（设备可选择是否执行）<br>0x02：删除订阅（设备需强制执行）<br>0x03：增加订阅（设备需强制执行） |

**设备回复：**

opcode： 0xCDD007

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x81 |
| 数据长度 | 1 | 0x03 |
| 数据 | Status(1byte) + Sub_addr(2byte) | Status: <br>0:添加成功 <br>1:超过群组数上限 <br>2:rfu <br>3:设置值超出范围 <br>4:rfu <br>5:其他错误 <br>Sub_addr：<br>设备需要增加/删除订阅的地址 |


同时为方便 App 查询遥控器与设备的绑定关系，在设备内需要实现以下命令(遥控器内无需实现)：

**App 发送：**

opcode： 0xC9D007

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x82 |
| 数据长度 | 1 | 0x00 |

**设备回复：**

opcode： 0xCDD007

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x82 |
| 数据长度 | 1 | 0x02 |
| 数据 | group_addr(2byte) | Group_addr：<br>接收到查询指令的目的地址，即APP所要查询的群组，此处即回复此地址；为防止大量回复造成网络风暴，对设备回复根据其 mesh 地址做相应延时。 |


## 特殊功能

### 带 TID 命令下发
#### 概述
由于 mesh 协议的特性，在数据包较大时需要分包传输，数据越长分包越多就会导致延时与丢包。由于 Tuya 产品在下发 DP 点控制后需要设备回复后 APP 上才会显示正确状态，所以如果数据包较长就会导致分包下发与分包上报。带 TID 命令下发，则设备只需要回复接收处理状态即可，提高了控制的响应速度与成功率。

#### 协议

**App 发送：**

op_code: 0xC8D007  WRITE_WITH_TID

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| TID | 1 | 传输 id 0-255 循环递增 |
| CMD | 1 | 0x01：DP 数据 |
| 数据 | N | datapoint组合（参考[蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)） |

**设备回复：**

op_code: 0xCBD007  STATUS

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| TID | 1 | 回复指定接收数据的 TID |
| status | 1 | 0x00：数据接收成功 <br> 其他：数据异常 |

#### SDK使用指导
参考 demo 中 app_common.c 文件中，在`OPERATE_RET app_mesh_data_recv(TAL_MESH_ACCESS_MSG_T *msg_raw, TAL_MESH_NET_PARAM_T *net_param)`函数中，处理`TAL_MESH_OPCODE_WRITE_WITH_TID`此 opcode 的数据，同时需要设备回复接收状态。

### Vendor 心跳
#### 概述
SDK 中已经集成此部分功能，自动化处理设备的心跳回复。但是心跳中可以附带设备的开关状态，如果将开关状态注册到心跳中，则可以通过心跳来查询设备的在线状态的同时附加获取设备的开关状态。

#### SDK使用指导
参考 demo 中 app_common.c 文件中，在`OPERATE_RET tuya_init_first(VOID_T)`函数中 `tal_mesh_heartbeat_onoff_info_set(1, &onoff_data, 1);` 的代码实现，此函数即开启心跳附带开关功能。


### 新状态回复通道
#### 概述
mesh 设备在进入 APP 面板时会从设备本地同步当前的状态，当设备有较多数据需要同步时可能会存在丢包的情况。所以如果将多个数据统一为一包或者几包数据，则会提高设备状态同步的效率。
但是针对于老版本 APP 与网关则仍会通过之前的通道进行查询，所以如果需要兼容老版本 APP 与网关，则需要保留以前的状态查询回复逻辑（sig model get 指令以及 0xCCD007 opcode 0x01 CMD 数据）。

#### 协议

**App 发送：**

op_code: 0xCCD007  READ

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x05 （新DP查询命令为0x05，老通道为0x01） |
| 数据长度 | 1 | N |
| 数据 | N * DP_ID(1byte) | Dp点序号组合 |

**设备回复：**

op_code: 0xCDD007  DATA

数据内容：

| 字段 | 长度 byte | 说明 |
| -- | -- | -- |
| 命令字 | 1 | 0x05（DP数据回复） |
| 数据 | N | Datapoint组合（参考[蓝牙 Mesh 设备 Vendor Model 透传规范](https://developer.tuya.com/cn/docs/iot-device-dev/tuya-sigmesh-device-vendor-model-access-standard?id=K9pikwhoo3gux)） |

#### SDK使用指导
SDK 中已经包含此消息的处理以及组包回复，但是设备的状态需要从应用层注册的回调中获取。

参考 app_common.c 文件中 `OPERATE_RET tuya_init_third(VOID_T)` 函数中接口调用 `tal_mesh_vendor_get_cb_init(app_mesh_vendor_get_recv);`，通过此接口将状态查询回调注册到 SDK 中。

同时在应用中实现`OPERATE_RET app_mesh_vendor_get_recv(UINT8_T dp_id, UINT8_T *dp_type, UINT8_T *dp_len, UINT8_T *dp_data)` 当 SDK 中收到状态查询指令时会通过此回调来查询设备的状态，开发者则需要在此函数中实现对应 DP 点数据的填充。













