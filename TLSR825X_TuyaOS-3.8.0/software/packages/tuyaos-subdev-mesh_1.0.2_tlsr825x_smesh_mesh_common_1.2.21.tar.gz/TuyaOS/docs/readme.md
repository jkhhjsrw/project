# 文档使用指导

## TuyaOS Mesh 平台开发指导

文档：[TuyaOS_BLE_Mesh_Developer_Guide](TuyaOS_BLE_Mesh_Developer_Guide.md)

内容：

1. mesh 基本概念解释
2. TuyaOS 环境搭建
3. 授权及 demo 上位机测试

## Mesh 产品开发指导

文档：[TuyaOS_BLE_Mesh_Application_Guide](TuyaOS_BLE_Mesh_Application_Guide.md)

内容：

1. Demo 相关功能指导
2. 工程配置方式
3. Mesh Category 释义与配置指导
4. 低功耗处理方式
5. 遥控器控制与本地联动策略说明

## Mesh API 操作指导

文档：[TuyaOS_BLE_Mesh_API_User_Guide](TuyaOS_BLE_Mesh_API_User_Guide.md)

内容：

1. Mesh 数据收发处理回调说明
2. Element 与 model 配置管理
3. 设备网络状态配置及状态回调
4. 设备产品配网信息配置
5. 部分 mesh 设备属性查询接口指导

## 芯片平台操作指导

文档：

[Tuya_BLE_Mesh_Platform_tlsr825x](Tuya_BLE_Mesh_Platform_tlsr825x.md)

[Tuya_BLE_Mesh_Platform_phy6222](Tuya_BLE_Mesh_Platform_phy6222.md)

内容：

1. 芯片手册下载
2. 外设操作指导
3. 固件烧录指导
4. 芯片平台 Flash 占用与划分
5. 基本工作功耗介绍