# TuyaOS BLE Mesh API 操作指南

参考 `tal_bluetooth_mesh_device.h` 中接口，可实现对 mesh 设备的初始化以及控制。

## 数据接收

参考 TuyaOS_BLE_Mesh_SDK_User_Guide 中设备能力值的设置，在不同的能力值时设备所使用的 mesh opcode 是不同的，所以在 mesh 数据的接收时想对应所使用的 opcode 才能正确的收到数据。

### 初始化

```c
OPERATE_RET tal_mesh_msg_recv_cb_init(tal_mesh_msg_recv_cb access_data_cb);
```

此函数用于注册 mesh 数据接收回调到 tal_bluetooth 组件中，当设备接收到控制命令时会调用注册的函数来将数据给到应用层处理。

```c
typedef OPERATE_RET (*tal_mesh_msg_recv_cb)(TAL_MESH_ACCESS_MSG_T *msg_raw, TAL_MESH_NET_PARAM_T *net_param);
```

对于回调函数，包括两个入参，msg_raw 与 net_param：

1. msg_raw：即access 层数据接收参数，包括数据的 opcode 与实际 data 数据的 hex格式(根据不同的 opcode 可将 hex data 转换为对应的结构话的数据)等。
2. net_param：即数据 network 层相关的参数，数据的 src_addr(源地址) 、dst_addr(目的地址)、SEQ(当前数据的序列号)、TTL(当前数据包中的TLL值)、RSSI(当前数据包接收到时的信号强度)等。

### 数据处理

opcode 为 access 层的类似 CMD ID 的属性，代表当前数据的类型。一般 client model 发送 get/set/set unack 等 opcode 给server model，server model 接收处理后回复 status opcode 给 client。上述为大部分 opcode 的使用方式，具体的可以根据蓝牙官方 model spec 中定义的使用。

可见在大部分的控制场景中，APP 、网关以及遥控器一般都是使用 client model，设备一般使用 server model。以此来实现设备间控制数据与状态回复数据的通信。

opcode 宏定义参考 tal_bluetooth_mesh_def.h 中定义，例如 Genric onoff set 所对应的宏定义为：

```c
#define TAL_MESH_OPCODE_ON_OFF_SET                      (0x8202)
```

同时收到的 opcode 的数据，将 hex data 转换为对应的数据格式也可以参考 tal_bluetooth_mesh_def.h 中的结构体定义，例如在收到 Genric onoff set 的数据时，可以将 \*data 转换为 \*TAL_MESH_GENERIC_ONOFF_SET_T 类型。

```c
 typedef struct{
     UCHAR_T onoff;                      /**< The target value of the Generic OnOff state. */
     UCHAR_T tid;                        /**< Transaction Identifier */
     UCHAR_T transit_t;                  /**< Generic Default Transition Time(optional). */
     UCHAR_T delay;                      /**< If the transit_t field is present, the Delay field shall also be present; otherwise these fields shall not be present. */
}TAL_MESH_GENERIC_ONOFF_SET_T;
```

数据接收处理与回复示例：

```c
OPERATE_RET app_mesh_data_recv(TAL_MESH_ACCESS_MSG_T *msg_raw, TAL_MESH_NET_PARAM_T *net_param){
    switch(msg_raw->opcode){
        case TAL_MESH_OPCODE_ON_OFF_SET:
        case TAL_MESH_OPCODE_ON_OFF_SET_UNACK:
            TAL_MESH_GENERIC_ONOFF_SET_T *onoff_set = (TAL_MESH_GENERIC_ONOFF_SET_T)msg_raw->data;
            BOOL_T onoff = onoff_set->onoff;
            light_onoff_set(onoff);

               TAL_MESH_GENERIC_ONOFF_STATUS_T onoff_status;
            onoff_status.present = onoff;
            onoff_status.target = onoff;
            onoff_status.remain_t = 0;
            if(TAL_MESH_OPCODE_ON_OFF_SET == msg_raw->opcode){
                tal_mesh_data_send(net_param->dst_addr, net_param->src_addr,             TAL_MESH_OPCODE_ON_OFF_STAT, &onoff_status, sizeof(onoff_status));
            }
            break;
        }
    }
```

## 数据发送

```c
OPERATE_RET tal_mesh_data_send(USHORT_T src_addr, USHORT_T dst_addr, UINT_T opcode, UCHAR_T *data, USHORT_T data_len);
```

此接口为 access 层接口发送，可以直接填发送的数据与 opcode，SDK 底层将按照顺序将数据按照当前的 network 层参数发送出去。dst_addr 为接收设备的目的地址，src_addr 则为发送数据的源地址，一般为设备自己的 unicast addr，可以通过 `tkl_mesh_primary_ele_addr_get();` 获取，如果 src_addr 填 0 或者 NULL，则 SDK 会自动转换为设备的主 element addr，对于多 element 类设备在填充 src_addr 时则要填写正确的 element addr（primary_ele_addr + element_index）。

当设备需要主动上报数据但是未知对端手机 APP 或者网关的 unicast_addr 时，可以上报数据时 dst_addr 填充为 `TUYA_REPROT_PUB_ADDR `(`tal_bluetooth_mesh_def.h`中的宏定义)，手机 APP 与网关会订阅此地址，向此地址发送的数据将会正常收到并处理

相关示例可以参考前面 [数据接收处理与回复示例](#data)；

## 群组添加与查询

```c
OPERATE_RET tal_group_addr_sub_set(UINT_T opcode, USHORT_T ele_index, USHORT_T group_addr);

#define TAL_MESH_OPCODE_CFG_MODEL_SUB_ADD               (0x801B)
#define TAL_MESH_OPCODE_CFG_MODEL_SUB_DELETE            (0x801C)
```

接口用于给指定的 model 增加或者删除订阅群组地址，SDK底层会自动对当前 element 的所有 model 进行订阅。

```c
USHORT_T* tal_group_addr_sub_list_get(USHORT_T ele_idx, USHORT_T model_id);
```

接口用于获取 element 指定 model 的订阅列表，目前设备支持的群组地址最大订阅数量为 32 个。

## element 与 model 管理

```c
OPERATE_RET tal_element_register(USHORT_T element_index);
OPERATE_RET tal_model_register(USHORT_T element_index, UINT_T model_id);
```

由于 Tlsr825x 平台的适配问题目前暂不支持用户注册，SDK 默认配置 6 个 element，model 默认配置如下表所示，如果有需要特殊修改请联系 Tuya 开发人员。其他平台则支持使用 TAL 中接口进行 element 与 model 的注册。

model 对应的 model id 以及 数据通信的结构格式可以参考 蓝牙官方 model spec，在  `tal_bluetooth_mesh_def.h` 也有相关的定义与 id 可以参考。

| element index | model                     | 说明                    |
|:-------------:| ------------------------- | --------------------- |
| 0             | config model              | 设备必备 model            |
| 0             | generic onoff model       | 开关 model              |
| 0             | light lightness model     | 亮度 model              |
| 0             | light ctl model           |                       |
| 0             | light ctl tempeture model | 色温 model              |
| 0             | light hsl model           | 彩光 model              |
| 0             | Tuya vendor model         | Tuya 自定义 vendor model |
| 1             | generic onoff model       | 开关 model              |
| 2             | generic onoff model       | 开关 model              |
| 3             | generic onoff model       | 开关 model              |
| 4             | generic onoff model       | 开关 model              |
| 5             | generic onoff model       | 开关 model              |

## 设备网络状态设置与回调

```c
typedef enum {
    MESH_NETWORK_RESET = 0x00,            /**< Kick out, mesh node will be unprovision state, and it will clear the mesh provision data in ram and flash */
    MESH_NETWORK_RESET_WITH_RECOVER,      /**< Node reset in tam, mesh node will be unprovision state, and it will clear the mesh provision data in ram. The provision data still store in flash */
    MESH_NETWORK_RECOVER,                 /**< Revcover the network, mesh node will be provision state, it will restore the provision data from flash into ram */
    } MESH_NETWORK_STATE_SET_T;

    OPERATE_RET tal_mesh_network_state_set(MESH_NETWORK_STATE_SET_T net_state);
```

通过此接口可以将设备重置为未配网状态。有两种重置方式，`MESH_NETWORK_RESET` 为设备彻底重置；`MESH_NETWORK_RESET_WITH_RECOVER` 则为可恢复的重置方式，重置之后如果没有新配网，set 为 `MESH_NETWORK_RESET_WITH_RECOVER` 或者将设备重启，设备都可以恢复到重置之前的网络。带恢复的方式一般用于误重置恢复功能，有些设备的重置可能是人为或者非人为的误操作，如果设备直接重置则需要手动重新配回网络，如果超时恢复则省去这个操作。 

```c
typedef enum{
    TAL_MESH_POWER_ON_UNPROVISION = 0,
    TAL_MESH_POWER_ON_PROVISIONED,
    TAL_MESH_PROVISION_SUCCESS,
    TAL_MESH_RESET,
    TAL_MESH_RESET_IN_RAM,
    TAL_MESH_REVERT_IN_MESH,
    TAL_MESH_GROUP_SUB_ADD,
    TAL_MESH_GROUP_SUB_DEL,
}TAL_MESH_NET_STATE_T;

TUYA_WEAK_ATTRIBUTE VOID tal_mesh_state_callback(TAL_MESH_NET_STATE_T state);
```

此函数为 mesh 设备状态的回调，开发者需要在应用层实现此函数的实例，则 SDK 在相关操作后会通过此函数给到业务层提示。（底层实现的方式为 weak 函数方式，如果业务层不实现则底层会使用一个空函数链接到固件中）

## 设备配网使能

```c
VOID tal_mesh_node_provision_enable(MESH_PROVISION_TYPE_T enable);
```

此接口可以开启或者关闭设备发送未配网广播，用于设备虽然处于未配网状态，但此时不想被 APP 或者网关配网或者用来实现配网时间窗口，超时后不允许配网等功能。

## 设备产品信息设置

```c
/**
  * @brief   Set the firmware information which mesh provision use.
  * @param   [in] is_key  use product key or product id
  * @param   [in] product_id  product id
  * @param   [in] product_key  product key
  * @param   [in] version  firmware version
  * @param   [in] mesh_category  mesh category define by tuya
  * @param   [in] need_publish_addr  if the device need a publish addr distributed by tuya cloud
  * @return  NULL
  * */
VOID tal_firmware_infor_set(UINT8_T is_key, UINT8_T *product_id, UINT8_T *product_key, UINT16_T version, UINT16_T mesh_category, UINT8_T need_publish_addr);
```

开发者需要在设备最开始初始化的时候调用此函数将产品信息更新到 SDK 中，SDK 会自动将这些信息填充到 mesh 协议栈中，配网时传输给 APP 来完成配网、鉴权与激活的动作。

Tuya 的编译脚本在编译时会自动将 IDE 与 json 中的配置信息以宏的形式生成，可以参考 demo 中的使用方式。

## 设备 uuid 设置与更新

```c
VOID tal_mesh_uuid_set(UCHAR_T* uuid);
```

用于更新 mesh uuid，uuid 的相关定义可以参考 mesh spec，除非特殊使用一般不建议直接调用此接口，因为 SDK 底层会自动根据初始化时填入的产品信息按照 Tuya 协议要求自动生成并更新 uuid。

```c
VOID tal_uuid_update(VOID);
```

uuid 更新接口，在节点初始化时会根据初始化填入的产品信息进行更新，如果用户修改了部分产品信息，则需要单独调用此接口进行 uuid 更新。

## 获取设备当前配网状态

```c
UCHAR_T tal_get_if_prov_success(VOID);
```

用于获取当前设备的配网状态（具体为 provision 状态）。但是对于 mesh 的标准配网分为两个阶段，为 provision 与 config 阶段，所以只有在 config 阶段完成后才是完整的配网成功，可以依据 `VOID tal_mesh_state_callback(TAL_MESH_NET_STATE_T state)` 推送的状态来确定。所以此接口一般不用于配网过程完成的检测。

## 获取设备的 unicast mesh addr

```c
USHORT_T tal_primary_ele_addr_get(VOID);
```

用于获取设备当前主 element 的地址，为配网时由 APP 或者网关分配。

```c
VOID tal_primary_ele_addr_set(USHORT_T addr, int flash_save_en);
```

用于设备主 element 地址的设置，一般用于未配网时的部分特殊操作，配网后禁止调用修改，否则会出现设备无法通信的问题。

## 设备高级能力 1

此功能为 3.6.0 之后版本 SDK 在呢个价，能力默认关闭，在开启后支持如下特点：

1. 支持 vendor model 命令查询设备 DP 状态，支持多 DP 打包。并将控制回复与查询回复进行区分，从而解决查询回复误触发自动化功能；（参考下文 新状态回复通道）

2. 支持 WRITE_WITH_TID 命令（仅当单设备控制、需要设备回复且 DP 数据在 mesh transprot 层需要分包时才会使用），收到此命令后设备只需要回复 TID 与接收状态，无需将完整 DP 数据返回，从而提高控制响应速度与成功率。

3. 支持使用 vendor model 心跳，心跳中可包含更多信息，组件中已经实现心跳的回复，应用无需额外处理；

具体协议参考：TuyaOS_BLE_Mesh_Application_Guide.md 中 特殊功能 章节。

```c
VOID_T tal_mesh_advanced_ability_1(UINT8_T enable);
```

默认此功能关闭，如果要使用可通过此接口使能。

## 新状态回复通道

```c
OPERATE_RET tal_mesh_vendor_get_cb_init(tal_mesh_vendor_get_cb vendor_data_get_cb);
```

此函数用于注册 mesh vendor model dp 查询回调到 tal_bluetooth 组件中，当设备接收到查询命令时会调用注册的函数来通知应用层，应用则需要将对应的 dp_id 的 dp_data 填充进去，组件内会自动实现组包。

```c
typedef OPERATE_RET (*tal_mesh_vendor_get_cb)(UINT8_T dp_id, UINT8_T *dp_type, UINT8_T *dp_len, UINT8_T *dp_data);
```

此定义为注册到组件中的函数实例类型，具体函数实现可以参考 demo 中 app_common.c 中的实现。

对于回调函数，入参有如下详细说明：

- dp_id：此次要查询的 dp id；
- *dp_type：dp 类型，需要回调内填充；
- *dp_len：dp 长度，具体数据长度需要回调内填充，bool / enum 为 1，value 为 4；
- *dp_data：dp 数据；

注意：

在使用此功能时，原来的状态查询通道仍需保留，用来兼容老版本的 APP 与网关。原来状态查询通道在 `app_mesh_data_recv`回调中，包括`TAL_MESH_OPCODE_ON_OFF_GET`等 sig model 的状态查询命令以及`TAL_MESH_OPCODE_READ`vendor model 查询通道。
